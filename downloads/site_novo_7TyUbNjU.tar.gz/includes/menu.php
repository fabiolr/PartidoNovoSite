<ul style="width: 821px; height: 62px; margin: 0 auto;">
                            <li>
                                <a id="balao_quemsomos" href="quemsomos.php" style="display: block; background: url(img/menu/quemsomos<?php if($pagina == 'quemsomos') { echo '_selecionado'; }?>.png); width: 139px; height: 37px;">Quem somos</a>
                                <div class="balao" style="width: 172px; height: 61px; background: url(img/menu/balao_quemsomos.png) top center no-repeat; display: none; position: absolute; top: 26px; margin-left: -2px; z-index: 9999;"></div>
                            </li>
                            <li>
                                <a id="balao_nossosideais" href="index.php#ideais" style="display: block; background: url(img/menu/nossosideais.png); width: 121px; height: 37px;">Nossos ideais</a>
                                <div class="balao" style="width: 219px; height: 61px; background: url(img/menu/balao_nossosideais.png) top center no-repeat; display: none; position: absolute; top: 26px; margin-left: -49px; z-index: 9999;"></div>
                            </li>
                            <li>
                                <a id="balao_comoparticipar" href="comoparticipar.php" style="display: block; background: url(img/menu/comoparticipar<?php if($pagina == 'comoparticipar') { echo '_selecionado'; }?>.png); width: 137px; height: 37px;">Como participar</a>
                                <div class="balao" style="width: 172px; height: 61px; background: url(img/menu/balao_comoparticipar.png) top center no-repeat; display: none; position: absolute; top: 26px; margin-left: -16px; z-index: 9999;"></div>
                            </li>
                            <li>
                                <a id="balao_acompanheonovo" href="acompanhe.php" style="display: block; background: url(img/menu/acompanheonovo<?php if($pagina == 'acompanhe') { echo '_selecionado'; }?>.png); width: 156px; height: 37px;">Acompanhe o NOVO</a>
                                <div class="balao" style="width: 185px; height: 81px; background: url(img/menu/balao_acompanheonovo.png) top center no-repeat; display: none; position: absolute; top: 26px; margin-left: -15px; z-index: 9999;"></div>
                            </li>
                            <li>
                                <a id="balao_saibamais" href="saibamais.php" style="display: block; background: url(img/menu/saibamais<?php if($pagina == 'saibamais') { echo '_selecionado'; }?>.png); width: 100px; height: 37px;">Saiba mais</a>
                                <div class="balao" style="width: 284px; height: 81px; background: url(img/menu/balao_saibamais.png) top center no-repeat; display: none; position: absolute; top: 26px; margin-left: -92px; z-index: 9999;"></div>
                            </li>
                            <li>
                                <a href="fale.php" style="display: block; background: url(img/menu/falecomagente<?php if($pagina == 'fale') { echo '_selecionado'; }?>.png); width: 168px; height: 37px;">Fale com a gente</a>
                            </li>
                        </ul>
