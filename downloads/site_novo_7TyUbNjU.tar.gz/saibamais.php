<?php

    $f = trim($_GET['f']);

    include("Mobile_Detect/Mobile_Detect.php");
    $detect = new Mobile_Detect();

    $pagina = 'saibamais';

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8 lt-ie7" lang="pt-BR"> <![endif]-->
<!--[if IE 7]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8" lang="pt-BR"> <![endif]-->
<!--[if IE 8]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9" lang="pt-BR"> <![endif]-->
<!--[if gt IE 8]><!--> <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js" lang="pt-BR"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>NOVO | Perguntas Frequentes</title>
        <link rel="image_src" href="http://www.novo.org.br/logo.jpg" />
        <meta name="description" content="Tire suas dúvidas e conheça os princípios, programas e estatuto do NOVO.">
        <meta name="viewport" content="width=1024">
        <meta name="author" content="Partido NOVO - Gestão e Cidadania" /> 
        <meta name="robots" content="index, follow" />
        <meta name="revisit" content="3 days" /> 
        <meta property="og:title" content="Partido NOVO - Perguntas Frequentes" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="http://www.novo.org.br/logo.jpg" />
        <meta property="og:url" content="http://www.novo.org.br/saibamais" />
        <meta property="og:description" content="Tire suas dúvidas e conheça os princípios, programas e estatuto do NOVO." />
        
        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">

        <!--[if IE]>
        <style>
            #topo_variavel div img {position: relative; top: -20px;}
        </style>
        <![endif]-->

        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
    <div id="fb-root"></div>
		<script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

        <div id="main" style="width: 100%; background: url(img/bg_textura_azul.jpg);">
            <header style="width: 100%; background: url(img/bg_textura_branco_interna.jpg);">
                <div id="header_in" style="width: 950px; margin: 0 auto;">
                    <nav>
                        <?php include("includes/menu.php"); ?>
                    </nav>
                    <div id="topo_fixo" style="width: 950px; height: 122px; position: relative; z-index: 9990;">
                        <a href="index.php"><img src="img/logo.png" alt="Partido NOVO | Gestão e Cidadania" border="0" /></a>

                        <div id="redessociais" style="float: right; margin-right: 4px;">
                            <div class="fb-like" data-href="http://facebook.com/partidonovo" data-send="false" data-width="290" data-show-faces="false" style="height: 30px; display: block; margin-bottom: 7px;"></div>
                            
                            <!--
                            <a href="http://www.twitter.com/desafionovo500" target="_blank"><img src="img/bt_twitter.png" alt="Partido NOVO | Twitter" style="float: right;" border="0" /><a/>
                            <a href="http://www.facebook.com/partidonovo" target="_blank"><img src="img/bt_facebook.png" alt="Partido NOVO | Facebook" style="float: right; margin-right: 6px;" border="0" /></a>
                            -->
                        </div>
                    </div>
                    <div style="clear: both;"><!-- --></div>
                    <div id="topo_variavel" style="width: 950px; height: 409px; margin: -51px 0 0 0;">
                        <div style="width: 950px; height: 409px;">
                            <img src="img/saibamais/topo.png" alt="Conheça os princípios, programas e estatuto do NOVO, e tire suas dúvidas." style="display: block;" />
                        </div>
                    </div>
                </div>
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
            </header>

            <div id="assine" style="width: 100%; height: 104px; background: url(img/bg_assine.png); margin-bottom: 7px;">
                <div id="assine_in" style="width: 950px; height: 61px; margin: 0 auto;"></div>
            </div>
                
            <a id="indice" href="#"><!-- --></a>

            <article id="pagina-saiba-mais" style="width: 950px; margin: 0 auto 65px auto;">
                <h1 style="width: 950px; height: 39px; background: url(img/saibamais/tit_saibamais.png) top center no-repeat; margin: 0 auto 47px auto; text-indent: -9999px;">Saiba Mais</h1>
                
                <div style="width: 950px; height: 47px; background: url(img/corner_top.png) top center no-repeat;"></div>
                <section style="width: 890px; padding: 21px 30px 18px 30px; background-color: #f4f0e7;">
        
                    <div style="width: 890px; margin-bottom: 62px;">
                        <div style="width: 890px; margin-bottom: 20px; float: left;">
                            <div style="width: 284px; height: 83px; margin-left: 156px; margin-right: 5px; float: left;">
                                <a href="saibamais_principios.php#indice"><img src="img/saibamais/bot_principios.png" alt="Princípios" border="0" /></a>
                            </div>
                            <div style="width: 284px; height: 83px; margin-left: 5px; float: left;">
                                <a href="saibamais_programa.php#indice"><img src="img/saibamais/bot_programa.png" alt="Programa" border="0" /></a>
                            </div>
                        </div>
                        <div style="width: 890px; float: left;">
                            <div style="width: 283px; height: 83px; margin-left: 10.5px; margin-right: 5px; float: left;">
                                <a href="saibamais_estatuto.php#indice"><img src="img/saibamais/bot_estatuto.png" alt="Estatuto" border="0" /></a>
                            </div>
                            <div style="width: 283px; height: 83px; margin: 0 5px; float: left;">
                                <a href="saibamais.php#indice"><img src="img/saibamais/bot_perguntasfrequentes_selecionado.png" alt="Perguntas Frequentes" border="0" /></a>
                            </div>
                            <div style="width: 283px; height: 83px; margin-left: 5px; float: left;">
                                <a href="saibamais_namidia.php#indice"><img src="img/saibamais/bot_novonamidia.png" alt="NOVO na mídia" border="0" /></a>
                            </div>
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                    
                    <a id="indice-saibamais"><!-- --></a>

                    <h2 style="font-family: Arial; width: 890px; text-align: center; font-size: 30px; line-height: 18px; color: #464646; margin-bottom: 31px;"><strong>PERGUNTAS FREQUENTES</strong></h2>
                    
                    <ul id="lista-perguntas-frequentes">
                        <li class="cinza"><a href="#p1">1) Por que criar mais um partido no Brasil?</a></li>
                        <li><a href="#p2">2) Quem são as pessoas que estão construindo o NOVO?</a></li>
                        <li class="cinza"><a href="#p3">3) Quem serão os políticos do NOVO?</a></li>
                        <li><a href="#p4">4) Qual a ideologia do NOVO?</a></li>
                        <li class="cinza"><a href="#p5">5) Como posso me filiar?</a></li>
                        <li><a href="#p6">6) Quando o NOVO lançará candidatos?</a></li>
                        <li class="cinza"><a href="#p7">7) Como posso participar?</a></li>
                        <li><a href="#p8">8) Quem pode participar?</a></li>
                        <li class="cinza"><a href="#p13">9) Qual a posição do NOVO sobre temas mais polêmicos?</a></li>
                        <li><a href="#p14">10) Como funciona a montagem de um partido?</a></li>
                        <li class="cinza"><a href="#p15">11) Quem está arcando com os custos da montagem do NOVO?</a></li>
                        <li><a href="#p16">12) Como garantir que o NOVO ﬁcará ﬁel aos seus princípios e valores? Que não vai se corromper?</a></li>
                        <li class="cinza"><a href="#p17">13) Qual o custo para o cidadão de se montar mais um partido?</a></li>
                        <li><a href="#p18">14) Se é tão difícil montar um partido, como existem tantos partidos no Brasil hoje?</a></li>
                        <li class="cinza"></li>
                        <li></li>
                        <li class="cinza"></li>
                        <li></li>
                    </ul>

                    <hr />
                    
                    <div id="perguntas-frequentes">
                        <div style="width: 890px;">

                            <h3 id="p1">1) Por que criar mais um partido no Brasil?</h3>

                            <p>De fato há um número elevado de partidos no cenário politico brasileiro mas, no nosso entender, dois critérios devem ser atendidos para que possamos considerar a existência de um verdadeiro partido:<br />	
                            <br />
                            
                            <span style="display: inline-block; padding-left: 41px;">
                            <strong>a)</strong> Para o NOVO um partido político representa um agrupamento de pessoas que compartilham os mesmos valores, crenças e objetivos. No cenário político brasileiro são raros os partidos hoje onde se consegue identiﬁcar o respeito a uma ideologia. A política nacional atual se caracteriza pela defesa de interesses pessoais, troca de favores e coligações inexplicáveis.<br /><br />

                            <strong>b)</strong> Os fundadores e apoiadores do NOVO não se consideram adequadamente representados por nenhum dos partidos existentes. Nenhum deles tem como objetivos principais os propostos pelo NOVO.</span></p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>

                            <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p2">2) Quem são as pessoas que estão construindo o NOVO?</h3>

                            <p>São pessoas que nunca tiveram a política como proﬁssão, mas que acreditam que o exercício da mesma é fundamental para a vida em sociedade. O NOVO está aberto a todos os que compartilham das nossas idéias e gostariam de tomar uma atitude em busca de propostas e soluções que ultrapassem as próximas eleições tendo como objetivo a melhoria da qualidade de vida de todos os cidadãos brasileiros. Dentre os fundadores, e na equipe do NOVO, não existem políticos proﬁssionais.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />
                        
                        <div style="width: 890px;">

                            <h3 id="p3">3) Quem serão os políticos do NOVO?</h3>

                            <p>Uma das principais bandeiras do  NOVO é a renovação dos quadros políticos atuais com a participação mais efetiva do cidadão na política. Em breve, quando o NOVO estiver registrado no TSE e puder lançar candidatos iremos buscar pessoas que compartilhem dos mesmos valores e objetivos. O NOVO será uma opção para políticos gestores que acreditam em um projeto de administração pública transparente, com base em prioridades, metas e o entendimento de que o dinheiro público é finito e fruto do sacrifício dos pagadores de impostos.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p4">4) Qual a ideologia do NOVO?</h3>

                            <p>O NOVO não acredita que rótulos antigos sejam uma boa deﬁnição da sua ideologia. Acreditamos num Estado Democrático que preserve as liberdades individuais, incentive o empreendedorismo, a concorrência, a participação do cidadão na vida política e tenha sua atuação focada nas áreas de educação básica, saúde, segurança, infraestrutura e na preservação da moeda.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p5">5) Como posso me filiar?</h3>

                            <p>O TSE, Tribunal Superior Eleitoral, só reconhece o processo de ﬁliação após o registro formal do partido, portanto, somente após recebermos o registro do TSE, que foi solicitado em Julho de 2014, poderemos receber a inscrição dos ﬁliados. </p>
                            <p>Nesta fase pré-registro a sua participação é muito importante para ajudar a divulgar o NOVO.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                          <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p6">6) Quando o NOVO lançará candidatos?</h3>

                            <p>A legislação eleitoral determina que o candidato a cargo eletivo deve estar ﬁliado ao partido há pelo menos um 1 ano para poder concorrer pela legenda. Sendo assim, conforme o explicado no item acima, após o registro ﬁnal do partido junto ao TSE teremos um prazo mínimo de 1 ano para lançamento de candidaturas pelo NOVO. </p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p7">7) Como posso participar?</h3>

                            <p>Neste momento pré-registro sua principal contribuição é a divulgação das idéias do NOVO entre seus amigos e pelas mídias sociais.<br /><br />

                            Saiba mais em: <a href="comoparticipar.php">Como participar</a>.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p8">8) Quem pode participar?</h3>

                            <p>O partido está aberto à participação de todos os cidadãos que compartilhem dos nossos ideais.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />
                        <div style="width: 890px;">

                          <h3 id="p13">9) Qual a posição do NOVO sobre temas mais polêmicos?</h3>

                            <p>Os temas mais polêmicos serão objeto de discussão depois do registro no TSE, dentro dos diretórios. Todas as propostas terão sempre como base os <a href="index.php#ideais">valores do NOVO</a>. Algumas destas discussões já podem ser acompanhadas através da <a href="http://www.facebook.com/partidonovo" target="_blank">página do NOVO no Facebook</a>.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                      </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p14">10) Como funciona a montagem de um partido?</h3>

                            <p>O processo de formação de um partido é extremamente burocrático e dispendioso. É necessário obter e validar 500 mil assinaturas de apoio de eleitores brasileiros (em papel), apresentá-las perante a justiça eleitoral para a conferência das assinaturas, constituir e estruturar vários Diretórios Estaduais e Municipais para poder solicitar o registro do partido no TSE.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p15">11) Quem está arcando com os custos da montagem do NOVO?</h3>

                            <p>Alguns dos fundadores do NOVO arcaram  com as despesas da criação do NOVO.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p16">12) Como garantir que o NOVO ﬁcará ﬁel aos seus princípios e valores? Que não vai se corromper?</h3>

                            <p>O estatuto do NOVO prevê órgãos de controle e a separação entre gestão partidária e atuação parlamentar. Mas caberá sempre aos ﬁliados e eleitores esclarecidos e cientes da sua responsabilidade como cidadãos cumprir este papel de ﬁscalizar o partido e penalizá-lo se houver algum desvio de curso. O NOVO desde a sua fundação tem procurado alertar e educar as pessoas dessas responsabilidades no processo político. Os fundadores do NOVO acreditam que o partido deve ter uma duração indeterminada e que as garantias não poderão ser baseadas no quadro atual de pessoas, mas sim num processo continuo com a participação de todos sempre atentos às idéias e princípios que devem reger um partido político.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p17">13) Qual o custo para o cidadão de se montar mais um partido?</h3>

                            <p>Nenhum. O fundo partidário e o tempo de televisão devem ser divididos entre os partidos existentes, logo, mais partidos signiﬁca apenas menos tempo de televisão e menor repasse do fundo partidário para cada partido e nenhum custo adicional para o cidadão.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>

                        <hr />

                        <div style="width: 890px;">

                            <h3 id="p18">14) Se é tão difícil montar um partido, como existem tantos partidos no Brasil hoje?</h3>

                            <p>Esses partidos foram criados e registrados antes da promulgação da Lei dos Partidos Políticos, (Lei nº 9096/95). Após esta lei, 12 partidos foram registrados: 6 deles já haviam sido fundados. De 2005 até hoje (Outubro de 2014), apenas 7 novos partidos foram registrados.</p>

                            <a href="#indice-saibamais" class="voltar">Voltar às perguntas</a>
                            <div style="clear: both;"></div>

                        </div>
                    </div>

                </section>
                <div style="width: 950px; height: 25px; background: url(img/corner_bottom.png) top center no-repeat;"></div>

                <div style="clear: both;"></div>
            </article>

            <footer style="width: 100%; height: 71px; background: url(img/bg_rodape.jpg);">
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
                <div id="footer_in" style="width: 927px; margin: 0 auto; padding: 21px 0 0 23px;">
                    <img src="img/logo_rodape.png" alt="Partido NOVO | Gestão e Cidadania" />

                    <a href="http://www.zaw.com.br/" target="_blank"><img src="img/zaw.png" alt="ZAW" style="float: right; margin-left: 40px; position: relative; bottom: -6px;" border="0" /></a>

                    <nav style="float: right;">
                        <ul>
                            <li><a href="javascript: return false;" onclick="$('body,html').animate({scrollTop: 0}, 800); return false;">De volta ao topo</a></li>
                        </ul>
                    </nav>
                </div>
            </footer>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.0.min.js"><\/script>')</script>

        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
        
        <?php if($detect->isMobile()) : ?>
        <script src="js/menu_mobile.js"></script>
        <?php else : ?>
        <script src="js/menu.js"></script>
        <?php endif; ?>

        <?php if(isset($f) && !empty($f)) : ?>
        <script>
        (function() {

            location.href= '#<?php echo $f; ?>';

        }());
        </script>
        <?php endif; ?>

        <script type="text/javascript">
          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-21651021-1']);
          _gaq.push(['_trackPageview']);

          (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	    ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();
        </script>
    </body>
</html>
