<?php
    
    $f = trim($_GET['f']);

    include("Mobile_Detect/Mobile_Detect.php");
    $detect = new Mobile_Detect();

    $pagina = 'acompanhe';

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8 lt-ie7" lang="pt-BR"> <![endif]-->
<!--[if IE 7]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8" lang="pt-BR"> <![endif]-->
<!--[if IE 8]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9" lang="pt-BR"> <![endif]-->
<!--[if gt IE 8]><!--> <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js" lang="pt-BR"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Acompanhe o NOVO</title>
        <link rel="image_src" href="http://www.novo.org.br/logo.jpg" />
        <meta name="description" content="Receba notícias sobre a evolução do NOVO.">
        <meta name="viewport" content="width=1024">
        <meta name="author" content="Partido NOVO - Gestão e Cidadania" /> 
        <meta name="robots" content="index, follow" />
        <meta name="revisit" content="3 days" /> 
        <meta property="og:title" content="Partido NOVO - Acompanhe o NOVO" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="http://www.novo.org.br/logo.jpg" />
        <meta property="og:url" content="http://www.novo.org.br/cadastro" />
        <meta property="og:description" content="Receba notícias sobre a evolução do NOVO." />

        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">

        <!--[if IE]>
        <style>
            #topo_variavel div img {position: relative; top: -20px;}
        </style>
        <![endif]-->

        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
		<script language="JavaScript" type="text/javascript" src="js/MascaraValidacao.js"></script> 

    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
<div id="fb-root"></div>
		<script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

        <div id="main" style="width: 100%; background: url(img/bg_textura_azul.jpg);">
            <header style="width: 100%; background: url(img/bg_textura_branco_interna.jpg);">
                <div id="header_in" style="width: 950px; margin: 0 auto;">
                    <nav>
                        <?php include("includes/menu.php"); ?>
                    </nav>
                    <div id="topo_fixo" style="width: 950px; height: 122px; position: relative; z-index: 9990;">
                        <a href="index.php"><img src="img/logo.png" alt="Partido NOVO | Gestão e Cidadania" border="0" /></a>

                        <div id="redessociais" style="float: right; margin-right: 4px;">
                            <div class="fb-like" data-href="http://facebook.com/partidonovo" data-send="false" data-width="290" data-show-faces="false" style="height: 30px; display: block; margin-bottom: 7px;"></div>
                            <!--
                            <a href="http://www.twitter.com/desafionovo500" target="_blank"><img src="img/bt_twitter.png" alt="Partido NOVO | Twitter" style="float: right;" border="0" /><a/>
                            <a href="http://www.facebook.com/partidonovo" target="_blank"><img src="img/bt_facebook.png" alt="Partido NOVO | Facebook" style="float: right; margin-right: 6px;" border="0" /></a>
                            -->
                        </div>
                    </div>
                    <div style="clear: both;"><!-- --></div>
                    <div id="topo_variavel" style="width: 950px; height: 409px; margin: -51px 0 0 0;">
                        <div style="width: 950px; height: 409px;">
                            <img src="img/acompanhe/topo.png" alt="Receba notícias sobre a evolução do NOVO por todo o Brasil preenchendo o cadastro abaixo." style="display: block;" />
                        </div>
                    </div>
                </div>
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
            </header>

            <div id="assine" style="width: 100%; height: 104px; background: url(img/bg_assine.png); margin-bottom: 7px;">
                <div id="assine_in" style="width: 950px; height: 61px; margin: 0 auto;"></div>
            </div>

            <article style="width: 950px; margin: 0 auto 65px auto;">
                <h1 style="width: 950px; height: 55px; background: url(img/acompanhe/tit_acompanheonovo.png) top center no-repeat; margin: 0 auto 47px auto; text-indent: -9999px;">Acompanhe o NOVO</h1>
                
                <div style="width: 950px; height: 47px; background: url(img/corner_top.png) top center no-repeat;"></div>
                <section style="width: 890px; padding: 0 30px 18px 30px; background-color: #f4f0e7;">
                    
                    <h2 style="font-family: Arial; font-size: 24px; color: #464646; margin-bottom: 43px;"><strong>REDES SOCIAIS</strong></h2>

                    <div style="width: 890px;">
                        <div style="width: 442px; height: 192px; border: none; border-right: #f68428 dotted 3px; float: left;">
                            <a href="http://www.facebook.com/partidonovo" target="_blank"><img src="img/icone_facebook.png" alt="" style="margin-left: 23px; margin-right: 29px; float: left;" border="0" /></a>

                            <h3 style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; width: 208px; float: left;">FACEBOOK</h3>

                            <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; display: inline-block; width: 208px;">Através da nossa página no Facebook mantemos um debate aberto sobre assuntos atuais, divulgamos nossas idéias e propostas. Acesse a página e faça parte deste movimento. Queremos ouvir você!</p>
                        </div>
                        <div style="width: 422px; height: 192px; float: left; padding-left: 20px;">
                            <a href="http://www.twitter.com/desafionovo500" target="_blank"><img src="img/icone_twitter.png" alt="" style="margin-left: 4px; margin-right: 5px; float: left;" border="0" /></a>

                            <h3 style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; width: 223px; float: left;">TWITTER</h3>

                            <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; display: inline-block; width: 223px;">Twitte e retwitte! Acesse e compartilhe o NOVO!</p>
                        </div>
                        <div style="clear: both;"></div>
                    </div>

                    <hr style="width: 890px; border: none; border-top: #bcb8ae solid 1px; border-bottom: #ffffff solid 1px; margin: 50px 0 44px 0;" />
                    
                    <a id="cadastro" href="#"><!-- --></a>


                    <?php if($_GET['opt'] == "out") : 
          
					include("includes/connection.php");
					mysql_select_db($database_connection, $connection);
					$remover = trim($_GET['email']);
					$insert_query = sprintf("update contacts set opt_out = 1 where email = '$remover'");
					$result = mysql_query($insert_query, $connection) or die(mysql_error());
					?>
                    
                  <h2 style="font-face: Arial; font-size: 29px; color: #f68428; margin-bottom: 27px;">Removido!!</h2>
                    Pedimos desculpas se nosso e-mail foi um incômodo. <br><br>
                    Você não receberá mais mensagens do NOVO no e-mail <?php echo $_GET['email'];?>.<br><br />Caso mude de idéia e queira voltar as receber as novidades do NOVO no seu e-mail, <a href="acompanhe.php#cadastro">cadastre-se</a> novamente.
<div style="height: 27px;"><!-- --></div>
                    Acompanhe o NOVO também pelo <a href="http://facebook.com/partidonovo" target="_blank">Facebook</a>.
                  
										
                    
					<?php else: 
				    if($_GET['enviado'] != 1) : ?>
                    
                    <h2 style="font-face: Arial; font-size: 29px; color: #f68428; margin-bottom: 27px;">Cadastre-se</h2>
                    <h3 style="font-face: Arial; font-size: 18px; color: #646564; font-weight: normal; margin-bottom: 40px;"><strong>Receba informativos do NOVO.</strong><br />
                    <div style="height: 27px;"><!-- --></div>
                    Complete o formulário abaixo para receber notícias sobre o NOVO.<br />
                    </h3>

                    <form method="post" action="../p/envia_cadastro_acompanhe.php" name="cadastro" enctype="multipart/form-data" onsubmit="envia_cadastro_acompanhe(this); return false;">
<label style="margin-left: 5px;">Nome:</label><input type="text" id="nome" name="nome" style="width: 278px; padding: 0 5px;" /><br />
                        <div style="height: 12px;"><!-- --></div>
                        <label style="margin-left: 5px;">E-mail:</label><input type="text" id="email" name="email" style="width: 278px; padding: 0 5px;" /><br />
                        <div style="height: 12px;"><!-- --></div>
                        <label style="margin-left: 5px;">CEP:</label><input type="text" id="cep" name="cep" style="width: 134px; padding: 0 5px;" onKeyPress="MascaraCep(cadastro.cep);"
 maength="10"/><label style="margin-left: 4px;">Profissão:</label><input type="text" id="profissao" name="profissao" style="width: 278px; padding: 0 5px;" /> <div style="height: 12px;"><!-- --></div>
                        <label style="margin-left: 5px;">Endereço:</label><input type="text" id="endereco" name="endereco" style="width: 350px; padding: 0 5px;" /><label style="margin-left: 16px;">Número:</label><input type="text" id="numero" name="numero" style="width: 50px; padding: 0 5px;"/><br />
                        <div style="height: 12px;"><!-- --></div>
                        <label style="margin-left: 5px;">Cidade:</label><input type="text" id="cidade" name="cidade" style="width: 134px; padding: 0 5px;" /><label style="margin-left: 16px; width: 65px;">Estado:</label><input type="text" id="estado" name="estado" style="width: 35px; padding: 0 5px;" maxlength="2" /><label style="margin-left: 8px;">Telefone:</label>
                        <input type="text" id="telefone" name="telefone" style="width: 144px; padding: 0 5px;" onKeyPress="MascaraTelefone(cadastro.telefone);"/><br />
                        <div style="height: 12px;"><!-- --></div>
                        <input type="checkbox" id="sms" name="sms" value="1" checked style=width: 15px; height: 100px; padding: 0px 0px;" />
                        <span style="vertical-align:8px; font-size: x-small;">
                        Autorizo o envio de SMS ou WhatsApp para meu telefone.
                        </span>
                        <br />
						<div style="height: 27px;"><!-- --></div>
                      <input type="image" name="submit" src="img/bt_formulario_enviar.png" style="width: 98px; height: 32px; border: none; outline: none;" />
                        <input type="hidden" id="action" name="action" value="submitform" />
                        <input type="hidden" name="charset_check" value="ä™®">
                    </form>                   
					
				  	<?php else: ?>
                    <h2 style="font-face: Arial; font-size: 29px; color: #f68428; margin-bottom: 27px;">Obrigado!</h2>
                    <h3 style="font-face: Arial; font-size: 18px; color: #646564; font-weight: normal; margin-bottom: 40px;"><strong>Agradecemos seu interesse pelo Partido NOVO.</strong><br />
                  <div style="height: 27px;"><!-- --></div>
                    Acompanhe o NOVO também pelo <a href="http://facebook.com/partidonovo" target="_blank">Facebook</a>.
					<?php endif; ?>

				  
				  <?php endif; ?>
                    
                    

            <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">
            </script>
            <script>
			$("#cep").blur(function(){
			var cep = this.value.replace(/[^0-9]/, "");
			if(cep.length!=8){
			return false;
			}
			var url = "http://viacep.com.br/ws/"+cep+"/json/";
			$.getJSON(url, function(dadosRetorno){
			try{
			// Insere os dados em cada campo
			$("#endereco").val(dadosRetorno.logradouro);
			$("#cidade").val(dadosRetorno.localidade);
			$("#estado").val(dadosRetorno.uf);
			}catch(ex){}
			});
			});
			</script>

                </section>
                <div style="width: 950px; height: 25px; background: url(img/corner_bottom.png) top center no-repeat;"></div>

                <div style="clear: both;"></div>
            </article>




            <footer style="width: 100%; height: 71px; background: url(img/bg_rodape.jpg);">
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
                <div id="footer_in" style="width: 927px; margin: 0 auto; padding: 21px 0 0 23px;">
                    <img src="img/logo_rodape.png" alt="Partido NOVO | Gestão e Cidadania" />

                    <a href="http://www.zaw.com.br/" target="_blank"><img src="img/zaw.png" alt="ZAW" style="float: right; margin-left: 40px; position: relative; bottom: -6px;" border="0" /></a>

                    <nav style="float: right;">
                        <ul>
                            <li><a href="javascript: return false;" onclick="$('body,html').animate({scrollTop: 0}, 800); return false;">De volta ao topo</a></li>
                        </ul>
                    </nav>
                </div>
            </footer>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.0.min.js"><\/script>')</script>

        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
        
        <?php if($detect->isMobile()) : ?>
        <script src="js/menu_mobile.js"></script>
        <?php else : ?>
        <script src="js/menu.js"></script>
        <?php endif; ?>

        <?php if(isset($f) && !empty($f)) : ?>
        <script>
        (function() {

            location.href= '#<?php echo $f; ?>';

        }());
        </script>
        <?php endif; ?>

        <script type="text/javascript">
          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-21651021-1']);
          _gaq.push(['_trackPageview']);

          (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();
        </script>
    </body>
</html>
