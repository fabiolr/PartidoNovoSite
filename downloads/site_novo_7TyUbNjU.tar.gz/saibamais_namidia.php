<?php

    $f = trim($_GET['f']);

    include("Mobile_Detect/Mobile_Detect.php");
    $detect = new Mobile_Detect();

    $pagina = 'saibamais';

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8 lt-ie7" lang="pt-BR"> <![endif]-->
<!--[if IE 7]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8" lang="pt-BR"> <![endif]-->
<!--[if IE 8]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9" lang="pt-BR"> <![endif]-->
<!--[if gt IE 8]><!--> <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js" lang="pt-BR"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>NOVO | Na Mídia</title>
        <link rel="image_src" href="http://www.novo.org.br/logo.jpg" />
        <meta name="description" content="Veja o NOVO na mídia.">
        <meta name="viewport" content="width=1024">
        <meta name="author" content="Partido NOVO - Gestão e Cidadania" /> 
        <meta name="robots" content="index, follow" />
        <meta name="revisit" content="3 days" /> 
        <meta property="og:title" content="Partido NOVO - Na Mídia" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="http://www.novo.org.br/logo.jpg" />
        <meta property="og:url" content="http://www.novo.org.br/midia" />
        <meta property="og:description" content="Veja o NOVO na mídia." />

        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">

        <!--[if IE]>
        <style>
            #topo_variavel div img {position: relative; top: -20px;}
        </style>
        <![endif]-->

        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
    <div id="fb-root"></div>
		<script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

        <div id="main" style="width: 100%; background: url(img/bg_textura_azul.jpg);">
            <header style="width: 100%; background: url(img/bg_textura_branco_interna.jpg);">
                <div id="header_in" style="width: 950px; margin: 0 auto;">
                    <nav>
                        <?php include("includes/menu.php"); ?>
                    </nav>
                    <div id="topo_fixo" style="width: 950px; height: 122px; position: relative; z-index: 9990;">
                        <a href="index.php"><img src="img/logo.png" alt="Partido NOVO | Gestão e Cidadania" border="0" /></a>

                        <div id="redessociais" style="float: right; margin-right: 4px;">
                            <div class="fb-like" data-href="http://facebook.com/partidonovo" data-send="false" data-width="290" data-show-faces="false" style="height: 30px; display: block; margin-bottom: 7px;"></div>
                            
                            <!--
                            <a href="http://www.twitter.com/desafionovo500" target="_blank"><img src="img/bt_twitter.png" alt="Partido NOVO | Twitter" style="float: right;" border="0" /><a/>
                            <a href="http://www.facebook.com/partidonovo" target="_blank"><img src="img/bt_facebook.png" alt="Partido NOVO | Facebook" style="float: right; margin-right: 6px;" border="0" /></a>
                            -->
                        </div>
                    </div>
                    <div style="clear: both;"><!-- --></div>
                    <div id="topo_variavel" style="width: 950px; height: 409px; margin: -51px 0 0 0;">
                        <div style="width: 950px; height: 409px;">
                            <img src="img/saibamais/topo.png" alt="Conheça os princípios, programas e estatuto do NOVO, e tire suas dúvidas." style="display: block;" />
                        </div>
                    </div>
                </div>
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
            </header>

            <div id="assine" style="width: 100%; height: 104px; background: url(img/bg_assine.png); margin-bottom: 7px;">
                <div id="assine_in" style="width: 950px; height: 61px; margin: 0 auto;"></div>
            </div>
            
            <a id="indice" href="#"><!-- --></a>

            <article id="pagina-saiba-mais-namidia" style="width: 950px; margin: 0 auto 65px auto;">
                <h1 style="width: 950px; height: 39px; background: url(img/saibamais/tit_saibamais.png) top center no-repeat; margin: 0 auto 47px auto; text-indent: -9999px;">Saiba Mais</h1>
                
                <div style="width: 950px; height: 47px; background: url(img/corner_top.png) top center no-repeat;"></div>
                <section style="width: 890px; padding: 21px 30px 18px 30px; background-color: #f4f0e7;">
        
                    <div style="width: 890px; margin-bottom: 62px;">
                        <div style="width: 890px; margin-bottom: 20px; float: left;">
                            <div style="width: 284px; height: 83px; margin-left: 156px; margin-right: 5px; float: left;">
                                <a href="saibamais_principios.php#indice"><img src="img/saibamais/bot_principios.png" alt="Princípios" border="0" /></a>
                            </div>
                            <div style="width: 284px; height: 83px; margin-left: 5px; float: left;">
                                <a href="saibamais_programa.php#indice"><img src="img/saibamais/bot_programa.png" alt="Programa" border="0" /></a>
                            </div>
                        </div>
                        <div style="width: 890px; float: left;">
                            <div style="width: 283px; height: 83px; margin-left: 10.5px; margin-right: 5px; float: left;">
                                <a href="saibamais_estatuto.php#indice"><img src="img/saibamais/bot_estatuto.png" alt="Estatuto" border="0" /></a>
                            </div>
                            <div style="width: 283px; height: 83px; margin: 0 5px; float: left;">
                                <a href="saibamais.php#indice"><img src="img/saibamais/bot_perguntasfrequentes.png" alt="Perguntas Frequentes" border="0" /></a>
                            </div>
                            <div style="width: 283px; height: 83px; margin-left: 5px; float: left;">
                                <a href="saibamais_namidia.php#indice"><img src="img/saibamais/bot_novonamidia_selecionado.png" alt="NOVO na mídia" border="0" /></a>
                            </div>
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                    
                    <a id="indice"><!-- --></a>

                    <h2 style="font-family: Arial; width: 890px; text-align: center; font-size: 30px; line-height: 18px; color: #464646; margin-bottom: 42px;"><strong>NOVO NA MÍDIA</strong></h2>
                    
                    <p><strong>Panorama Mercantil</strong><br />
                    <em>“Nada recebido do Governo é gratuito”</em><br />
                    Data: 07/03/2013<br />
                    Entrevista de João Dionisio Amoêdo - Presidente do partido NOVO.<br />
                    <a href="http://www.panoramamercantil.com.br/nada-recebido-do-governo-e-gratuito-joao-dionisio-amoedo-presidente-do-partido-novo/" target="_blank">Clique aqui</a><br /><br />

                    <strong>TV Globo - TO</strong><br />
                    <em>Matéria sobre a criação do NOVO em Tocantins. Inclui entrevista com Diego Passoni, líder no estado.</em><br />
                    Data: 10/05/2012<br />
                    Matéria sobre o NOVO.<br />
                    <a href="http://vimeo.com/42287705" target="_blank">Clique aqui</a><br /><br />
                    
                    <!--
                    <strong>Jornal O Girassol</strong><br />
                    <em>Partido NOVO será lançado para a comunidade tocantinense.</em><br />
                    Data: 10/05/2012<br />
                    Partido NOVO em Palmas.<br />
                    <a href="http://www.ogirassol.com.br/pagina.php?editoria=%C3%9Altimas%20Not%C3%ADcias&idnoticia=39202" target="_blank">Clique aqui</a><br /><br />
                    -->
                   
                    <strong>Jornal O Folha</strong><br />
                    <em>Advogado e Sociólogo José Luiz Gama representará o Partido NOVO no Maranhão</em><br />
                    Data: 16/04/2012<br />
                    Partido NOVO no Maranhão.<br />
                    <a href="http://ofolha.com.br/?page=ler&id=2067" target="_blank">Clique aqui</a><br /><br />
                    
                    <strong>Revista Época</strong><br />
                    <em>Executivos organizam partido que promete gestão empresarial</em><br />
                    Data: 09/06/2011<br />
                    Entrevista com João Dionísio Amoedo, Presidente do Diretório Nacional do NOVO.<br />
                    <a href="http://revistaepoca.globo.com/EditoraGlobo2/Materia/exibir.ssp?materiaId=240537&secaoId=15223" target="_blank">Clique aqui</a><br /><br />

                    <strong>Rádio CBN</strong><br />
                    <em>Iniciativas positivas para apoiar a reforma política</em><br />
                    Data: 10/05/2011<br />
                    Matéria na rádio CBN sobre o NOVO.<br />
                    <a href="http://cbn.globoradio.globo.com/colunas/a-voz-do-cidadao/2011/05/10/INICIATIVAS-POSITIVAS-PARA-APOIAR-A-REFORMA-POLITICA.htm" target="_blank">Clique aqui</a><br /><br />
                    
                    <strong>Instituto Millenium</strong><br />
                    <em>Hora de mudanças</em><br />
                    Data: 23/03/2011<br />
                    O NOVO foi citado no blog do Instituto Millenium.<br />
                    <a href="http://www.imil.org.br/artigos/hora-de-mudanas/" target="_blank">Clique aqui</a><br /><br />
                    
                    <strong>Tribuna do Norte</strong><br />
                    <em>'Prioridades do Partido NOVO são gestão e cidadania'</em><br />
                    Data: 20/03/2011<br />
                    Entrevista com João Dionísio Amoedo, Presidente do Diretório Nacional.<br />
                    <a href="http://tribunadonorte.com.br/noticia/prioridades-do-partido-novo-sao-gestao-e-cidadania/176066" target="_blank">Clique aqui</a><br /><br />
                    
                    <strong>Jornal Valor Econômico</strong><br />
                    <em>Executivos criam sigla inspirada no mercado.</em><br />
                    Data: 15/03/2011<br />
                    João Dionísio Amoedo fala sobre a criação do NOVO.<br />
                    <a href="http://www.valor.com.br/arquivo/877165/executivos-criam-sigla-inspirada-no-mercado" target="_blank">Clique aqui</a><br /><br />
                    
                    <strong>O Fluminense</strong><br />
                    <em>Partido NOVO tenta ser a 28a legenda em atividade no país</em><br />
                    Data: 13 e 14/03/2011<br />
                    Matéria sobre o NOVO. Leia na página 6.<br />
                    <a href="http://flipagem.ofluminense.com.br/flip.asp?iidpublicacao=1&flargura=&ed=39182&pag=1&pc" target="_blank">Clique aqui</a><br /><br />
                    
                    <strong>IstoÉ Dinheiro</strong><br />
                    <em>Partido de empresário</em><br />
                    Data: 11/03/2011<br />
                    João Dionísio Amoedo, Presidente do Diretório Nacional, fala sobre o NOVO.<br />
                    <a href="http://www.istoedinheiro.com.br/noticias/51413_PARTIDO+DE+EMPRESARIO" target="_blank">Clique aqui</a><br /><br />
                    
                    <strong>Diplomatizzando</strong><br />
                    <em>Apoiando um Partido NOVO (novo mesmo...): pelo menos se espera...</em><br />
                    Data: 11/03/2011<br />
                    A opinão do blogueiro Paulo Roberto de Almeida sobre o NOVO.<br />
                    <a href="http://diplomatizzando.blogspot.com/2011/03/apoiando-um-partido-novo-novo-mesmo.html" target="_blank">Clique aqui</a><br /><br />
                    
                    <strong>Opinião & Notícia</strong><br />
                    <em>Partido NOVO quer legenda "sem políticos".</em><br />
                    Data: 05/03/2011<br />
                    Matéria sobre o NOVO.<br />
                    <a href="http://opiniaoenoticia.com.br/brasil/partido-novo-quer-legenda-sem-politicos/" target="_blank">Clique aqui</a><br /><br />
                   
                    <strong>Folha de São Paulo</strong><br />
                    <em>Nossos candidatos terão metas de gestão</em><br />
                    Data: 05/03/2011<br />
                    João Dionísio Amoedo fala sobre o desafio de criar o NOVO.<br />
                    <a href="http://www1.folha.uol.com.br/poder/884845-executivos-organizam-partido-que-promete-gestao-empresarial.shtml" target="_blank">Clique aqui</a></p>

                </section>
                <div style="width: 950px; height: 25px; background: url(img/corner_bottom.png) top center no-repeat;"></div>

                <div style="clear: both;"></div>
            </article>

            <footer style="width: 100%; height: 71px; background: url(img/bg_rodape.jpg);">
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
                <div id="footer_in" style="width: 927px; margin: 0 auto; padding: 21px 0 0 23px;">
                    <img src="img/logo_rodape.png" alt="Partido NOVO | Gestão e Cidadania" />

                    <a href="http://www.zaw.com.br/" target="_blank"><img src="img/zaw.png" alt="ZAW" style="float: right; margin-left: 40px; position: relative; bottom: -6px;" border="0" /></a>

                    <nav style="float: right;">
                        <ul>
                            <li><a href="javascript: return false;" onclick="$('body,html').animate({scrollTop: 0}, 800); return false;">De volta ao topo</a></li>
                        </ul>
                    </nav>
                </div>
            </footer>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.0.min.js"><\/script>')</script>

        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
        
        <?php if($detect->isMobile()) : ?>
        <script src="js/menu_mobile.js"></script>
        <?php else : ?>
        <script src="js/menu.js"></script>
        <?php endif; ?>

        <?php if(isset($f) && !empty($f)) : ?>
        <script>
        (function() {

            location.href= '#<?php echo $f; ?>';

        }());
        </script>
        <?php endif; ?>

        <script type="text/javascript">
          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-21651021-1']);
          _gaq.push(['_trackPageview']);

          (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();
        </script>
    </body>
</html>
