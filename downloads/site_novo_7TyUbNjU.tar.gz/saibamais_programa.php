<?php

    $f = trim($_GET['f']);

    include("Mobile_Detect/Mobile_Detect.php");
    $detect = new Mobile_Detect();

    $pagina = 'saibamais';

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8 lt-ie7" lang="pt-BR"> <![endif]-->
<!--[if IE 7]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8" lang="pt-BR"> <![endif]-->
<!--[if IE 8]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9" lang="pt-BR"> <![endif]-->
<!--[if gt IE 8]><!--> <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js" lang="pt-BR"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>NOVO | Programa</title>
        <link rel="image_src" href="http://www.novo.org.br/logo.jpg" />
        <meta name="description" content="Conheça o Programa do NOVO.">
        <meta name="viewport" content="width=1024">
        <meta name="author" content="Partido NOVO - Gestão e Cidadania" /> 
        <meta name="robots" content="index, follow" />
        <meta name="revisit" content="3 days" /> 
        <meta property="og:title" content="Partido NOVO - Programa" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="http://www.novo.org.br/logo.jpg" />
        <meta property="og:url" content="http://www.novo.org.br/programa" />
        <meta property="og:description" content="Conheça o Programa do NOVO." />

        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">

        <!--[if IE]>
        <style>
            #topo_variavel div img {position: relative; top: -20px;}
        </style>
        <![endif]-->

        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
    <div id="fb-root"></div>
		<script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

        <div id="main" style="width: 100%; background: url(img/bg_textura_azul.jpg);">
            <header style="width: 100%; background: url(img/bg_textura_branco_interna.jpg);">
                <div id="header_in" style="width: 950px; margin: 0 auto;">
                    <nav>
                        <?php include("includes/menu.php"); ?>
                    </nav>
                    <div id="topo_fixo" style="width: 950px; height: 122px; position: relative; z-index: 9990;">
                        <a href="index.php"><img src="img/logo.png" alt="Partido NOVO | Gestão e Cidadania" border="0" /></a>

                        <div id="redessociais" style="float: right; margin-right: 4px;">
                            <div class="fb-like" data-href="http://facebook.com/partidonovo" data-send="false" data-width="290" data-show-faces="false" style="height: 30px; display: block; margin-bottom: 7px;"></div>
                            
                            <!--
                            <a href="http://www.twitter.com/desafionovo500" target="_blank"><img src="img/bt_twitter.png" alt="Partido NOVO | Twitter" style="float: right;" border="0" /><a/>
                            <a href="http://www.facebook.com/partidonovo" target="_blank"><img src="img/bt_facebook.png" alt="Partido NOVO | Facebook" style="float: right; margin-right: 6px;" border="0" /></a>
                            -->
                        </div>
                    </div>
                    <div style="clear: both;"><!-- --></div>
                    <div id="topo_variavel" style="width: 950px; height: 409px; margin: -51px 0 0 0;">
                        <div style="width: 950px; height: 409px;">
                            <img src="img/saibamais/topo.png" alt="Conheça os princípios, programas e estatuto do NOVO, e tire suas dúvidas." style="display: block;" />
                        </div>
                    </div>
                </div>
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
            </header>

            <div id="assine" style="width: 100%; height: 104px; background: url(img/bg_assine.png); margin-bottom: 7px;">
                <div id="assine_in" style="width: 950px; height: 61px; margin: 0 auto;"></div>
            </div>

            <a id="indice" href="#"><!-- --></a>

            <article id="pagina-saiba-mais-programa" style="width: 950px; margin: 0 auto 65px auto;">
                <h1 style="width: 950px; height: 39px; background: url(img/saibamais/tit_saibamais.png) top center no-repeat; margin: 0 auto 47px auto; text-indent: -9999px;">Saiba Mais</h1>
                
                <div style="width: 950px; height: 47px; background: url(img/corner_top.png) top center no-repeat;"></div>
                <section style="width: 890px; padding: 21px 30px 18px 30px; background-color: #f4f0e7;">
        
                    <div style="width: 890px; margin-bottom: 62px;">
                        <div style="width: 890px; margin-bottom: 20px; float: left;">
                            <div style="width: 284px; height: 83px; margin-left: 156px; margin-right: 5px; float: left;">
                                <a href="saibamais_principios.php#indice"><img src="img/saibamais/bot_principios.png" alt="Princípios" border="0" /></a>
                            </div>
                            <div style="width: 284px; height: 83px; margin-left: 5px; float: left;">
                                <a href="saibamais_programa.php#indice"><img src="img/saibamais/bot_programa_selecionado.png" alt="Programa" border="0" /></a>
                            </div>
                        </div>
                        <div style="width: 890px; float: left;">
                            <div style="width: 283px; height: 83px; margin-left: 10.5px; margin-right: 5px; float: left;">
                                <a href="saibamais_estatuto.php#indice"><img src="img/saibamais/bot_estatuto.png" alt="Estatuto" border="0" /></a>
                            </div>
                            <div style="width: 283px; height: 83px; margin: 0 5px; float: left;">
                                <a href="saibamais.php#indice"><img src="img/saibamais/bot_perguntasfrequentes.png" alt="Perguntas Frequentes" border="0" /></a>
                            </div>
                            <div style="width: 283px; height: 83px; margin-left: 5px; float: left;">
                                <a href="saibamais_namidia.php#indice"><img src="img/saibamais/bot_novonamidia.png" alt="NOVO na mídia" border="0" /></a>
                            </div>
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                    
                    <a id="indice"><!-- --></a>

                    <h2 style="font-family: Arial; width: 890px; text-align: center; font-size: 30px; line-height: 18px; color: #464646; margin-bottom: 42px;"><strong>PROGRAMA DO NOVO</strong></h2>
                    
                    <p>Sempre atuando em conformidade com sua Declaração de Princípios, o NOVO nasce para ser uma opção de simplicidade, seriedade, transparência e eficiência no cenário político brasileiro.<br /><br />

                    Os objetivos segmentados por tópicos são:<br /><br />


                    <strong>I - SOCIEDADE</strong></p>
                    
                    <ul>
                        <li>Criar um novo espaço no cenário político nacional;</li>
                        <li>Fomentar o senso de cidadania nos indivíduos;</li>
                        <li>Atrair e engajar pessoas que se disponham a contribuir com idéias, esforço, talento e competências, em prol das gerações futuras.</li>
                    </ul>

                    <p><strong>II - PARTIDO</strong></p>
                    
                    <ul>
                        <li>Ser uma plataforma institucional onde os cidadãos que compartilhem dos princípios do NOVO possam efetivamente participar da vida pública;</li>
                        <li>Estabelecer uma estrutura partidária que mantenha ao longo do tempo as características e a identidade do partido, minimizando os riscos do interesse individual se sobrepor ao coletivo;</li>
                        <li>Diferenciar, em razão das finalidades e prioridades, a gestão partidária da gestão pública;</li>
                        <li>Propor candidaturas de cidadãos que apresentem competência para o exercício do cargo que disputam, compartilhem dos mesmos princípios e ideais e tenham como prioridade a melhoria do bem comum;</li>
                        <li>Apoiar e acompanhar os candidatos do NOVO eleitos, a fim de viabilizar nos seus mandatos os compromissos assumidos em campanha.</li>
                    <ul>

                    <p><strong>III - ESTADO</strong></p>
                    
                    <ul>
                        <li>Atuar com eficiência na administração pública, zelando pelo cumprimento da Constituição Federal.</li>
                        <li>Gerir o patrimônio público e os impostos arrecadados utilizando os critérios de racionalidade, eficiência e honestidade, visando a melhoria da qualidade e abrangência dos serviços prestados aos cidadãos.</li>
                        <li>O NOVO pretende ser um pacto entre cidadãos conscientes do que seja cidadania, para ocupar os espaços possíveis na gestão do Estado, preenchendo-os com a racionalidade, a coragem, o conhecimento, as virtudes e os atributos necessários para que as prioridades da sociedade sejam atendidas ao menor custo e na maior extensão que se possam combinar na construção de um país moderno, democrático e republicano.</li>
                    </ul>

                    <p style="margin-top: 45px;"><a href="downloads/Programa.pdf" target="_blank">Download do Programa em PDF</a></p>

                </section>
                <div style="width: 950px; height: 25px; background: url(img/corner_bottom.png) top center no-repeat;"></div>

                <div style="clear: both;"></div>
            </article>

            <footer style="width: 100%; height: 71px; background: url(img/bg_rodape.jpg);">
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
                <div id="footer_in" style="width: 927px; margin: 0 auto; padding: 21px 0 0 23px;">
                    <img src="img/logo_rodape.png" alt="Partido NOVO | Gestão e Cidadania" />

                    <a href="http://www.zaw.com.br/" target="_blank"><img src="img/zaw.png" alt="ZAW" style="float: right; margin-left: 40px; position: relative; bottom: -6px;" border="0" /></a>

                    <nav style="float: right;">
                        <ul>
                            <li><a href="javascript: return false;" onclick="$('body,html').animate({scrollTop: 0}, 800); return false;">De volta ao topo</a></li>
                        </ul>
                    </nav>
                </div>
            </footer>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.0.min.js"><\/script>')</script>

        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
        
        <?php if($detect->isMobile()) : ?>
        <script src="js/menu_mobile.js"></script>
        <?php else : ?>
        <script src="js/menu.js"></script>
        <?php endif; ?>

        <?php if(isset($f) && !empty($f)) : ?>
        <script>
        (function() {

            location.href= '#<?php echo $f; ?>';

        }());
        </script>
        <?php endif; ?>

        <script type="text/javascript">
          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-21651021-1']);
          _gaq.push(['_trackPageview']);

          (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();
        </script>
    </body>
</html>
