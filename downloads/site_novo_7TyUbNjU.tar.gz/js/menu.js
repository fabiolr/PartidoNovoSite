(function() {
    
    $("#balao_saibamais").mouseenter(function() {

        $(this).next("div").show();

    }).mouseleave(function() {

        $(this).next("div").hide();

    });

    $("#balao_acompanheonovo").mouseenter(function() {

        $(this).next("div").show();

    }).mouseleave(function() {

        $(this).next("div").hide();

    });

    $("#balao_comoparticipar").mouseenter(function() {

        $(this).next("div").show();

    }).mouseleave(function() {

        $(this).next("div").hide();

    });

    $("#balao_nossosideais").mouseenter(function() {

        $(this).next("div").show();

    }).mouseleave(function() {

        $(this).next("div").hide();

    });

    $("#balao_quemsomos").mouseenter(function() {

        $(this).next("div").show();

    }).mouseleave(function() {

        $(this).next("div").hide();

    });

}());