var membros = [["biancabacha", "1"],
               ["christianlohbauer", "1"],
               ["claudiobarra", "1"],
               ["diegopassoni", "1"],
               ["elisonamaral", "1"],
               ["erichtavares", "1"],
               ["fabioribeiro", "1"],
               ["flaviagoulart", "1"],
               ["josehumberto", "1"],
               ["joseluiz", "1"],
               ["luisclaudio", "1"],
               ["marcosalcantara", "1"],
               ["mariabeatriz", "1"],
               ["marianaamoedo", "1"],
               ["massaohatae", "1"],
               ["paulacorrente", "1"],
               ["raphaellaburti", "1"],
               ["renatonalini", "1"],
               ["ricardopelucio", "1"]];

var dominio = "http://www.novo.org.br/";

(function() {
    
	for(var i = 0; i < membros.length; i++) {

		eval('var i_tag' + i + ' = new Image();');
 		eval('i_tag' + i + '.src = "' + dominio + 'img/home/tag_' + membros[i][0] + '.png";');

	}

	for(var i = 0; i < membros.length; i++) {

		eval('var i_slide' + i + ' = new Image();');
 		eval('i_slide' + i + '.src = "' + dominio + 'img/home/slide_' + membros[i][0] + '.png";');

	}

}());