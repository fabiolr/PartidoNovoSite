(function() {

    $("#balao_nossosideais").click(function() {

        $(this).css('background-image', 'url(img/menu/nossosideais_selecionado.png)');

    });

}());