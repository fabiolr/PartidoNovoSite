var balao_saibamais_opened      = false;
var balao_acompanheonovo_opened = false;
var balao_comoparticipar_opened = false;
var balao_nossosideais_opened   = false;
var balao_quemsomos_opened      = false;

function fechaOutros(atual) {

    if('balao_saibamais' != atual) {
        $("#balao_saibamais").next("div").hide();
        balao_saibamais_opened = false;
    }

    if('balao_acompanheonovo' != atual) {
        $("#balao_acompanheonovo").next("div").hide();
        balao_acompanheonovo_opened = false;
    }

    if('balao_comoparticipar' != atual) {
        $("#balao_comoparticipar").next("div").hide();
        balao_comoparticipar_opened = false;
    }

    if('balao_nossosideais' != atual) {
        $("#balao_nossosideais").next("div").hide();
        balao_nossosideais_opened = false;
    }

    if('balao_quemsomos' != atual) {
        $("#balao_quemsomos").next("div").hide();
        balao_quemsomos_opened = false;
    }

}

(function() {
    
    $("#balao_saibamais").click(function(e) {

        fechaOutros('balao_saibamais');

        if(balao_saibamais_opened) {

            location.href = $(this).attr("href");

        } else {

            $(this).next("div").show();

            balao_saibamais_opened = true;

        }

        e.preventDefault();

    });

    $("#balao_acompanheonovo").click(function(e) {

        fechaOutros('balao_acompanheonovo');

        if(balao_acompanheonovo_opened) {

            location.href = $(this).attr("href");

        } else {

            $(this).next("div").show();

            balao_acompanheonovo_opened = true;

        }

        e.preventDefault();

    });

    $("#balao_comoparticipar").click(function(e) {

        fechaOutros('balao_comoparticipar');

        if(balao_comoparticipar_opened) {

            location.href = $(this).attr("href");

        } else {

            $(this).next("div").show();

            balao_comoparticipar_opened = true;

        }

        e.preventDefault();

    });

    $("#balao_nossosideais").click(function(e) {

        fechaOutros('balao_nossosideais');

        if(balao_nossosideais_opened) {

            location.href = $(this).attr("href");

        } else {

            $(this).next("div").show();

            balao_nossosideais_opened = true;

        }

        e.preventDefault();

    });

    $("#balao_quemsomos").click(function(e) {

        fechaOutros('balao_quemsomos');

        if(balao_quemsomos_opened) {

            location.href = $(this).attr("href");

        } else {

            $(this).next("div").show();

            balao_quemsomos_opened = true;

        }

        e.preventDefault();

    });

}());