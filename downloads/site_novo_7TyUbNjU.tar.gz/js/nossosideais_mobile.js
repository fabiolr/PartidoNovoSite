(function() {

    $("#balao_nossosideais").click(function(e) {

        fechaOutros('balao_nossosideais');

        if(balao_nossosideais_opened) {

            $(this).next("div").hide();

            $(this).css('background-image', 'url(img/menu/nossosideais_selecionado.png)');

        } 

    });

}());