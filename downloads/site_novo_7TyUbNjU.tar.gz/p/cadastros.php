<html>
<head>
<title>Cadastros NOVO</title>
<body>
<p><b>Monitoramento Novos Cadastros</b></p>

  <table class="striped">
        <tr class="header">
            <td></td>
            <td></td>
            
        </tr>

<?php
include("../includes/connection.php");
mysql_select_db($database_connection);
$sql="SELECT count(id) FROM contacts;
";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);
echo "<tr class=\"".$class."\">";
echo "<td>TOTAL</td>";
echo "<td>".$row["count(id)"]."</td></tr>";


$sql="select count(distinct(email)) from contacts;
";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);
echo "<tr class=\"".$class."\">";
echo "<td> "E-mails Distintos</td>";
echo "<td>".$row["count(distinct(email))"]."</td></tr>";


$sql="SELECT count(id) FROM contacts WHERE DATE_SUB(CURDATE(),INTERVAL 30 DAY) <= date;
";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);

echo "<tr class=\"".$class."\">";
echo "<td> "Nos últimos 30 dias</td>";
echo "<td>".$row["count(id)"]."</td></tr>";


$sql="SELECT count(id) FROM contacts WHERE DATE_SUB(CURDATE(),INTERVAL 7 DAY) <= date;
";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);

echo "<tr class=\"".$class."\">";
echo "<td> "Nos últimos 7 dias</td>";
echo "<td>".$row["count(id)"]."</td></tr>";


$sql="SELECT count(id) FROM contacts WHERE DATE_SUB(CURDATE(),INTERVAL 1 DAY) <= date;
";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);
echo "<tr class=\"".$class."\">";
echo "<td> "Nas últimas 24 horas</td>";
echo "<td>".$row["count(id)"]."</td></tr>";
echo "<p>Últimos 10 Cadastros:<p>";

$sql = "SELECT name,email,cidade FROM contacts ORDER BY id DESC LIMIT 10;
";
$result = mysql_query($sql);

?>
</table>
  <table class="striped">
        <tr class="header">
            <td>Name</td>
            <td>email</td>
            <td>Cidade</td>
        </tr>
        <?php
        $i = 0;
	while ($row = mysql_fetch_array($result)) {
               $class = ($i == 0) ? "" : "alt";
               echo "<tr class=\"".$class."\">";
               echo "<td>".$row["name"]."</td>";
               echo "<td>".$row["email"]."</td>";
               echo "<td>".$row["cidade"]."</td>";
               echo "</tr>";
               $i = ($i==0) ? 1:0;
           }

        ?>
    </table>

</body>
</html>
