<html>
<head>
<meta charset="ISO-8859-1">
<title>Cadastros NOVO</title>
<body>
<p><b>Monitoramento Novos Cadastros</b></p>


	<?php

	include("../includes/connection.php");

	mysql_select_db($database_connection);

	$sql="SELECT count(id) FROM contacts;";
	$result=mysql_query($sql);
	$row=mysql_fetch_array($result);
	$total = $row["count(id)"];
?>
	  <table class="striped">
		<tr class="header">
		<td>TOTAL:</td>
		<td><?php echo $total;?></TD>
		</tr>
	<tr class="header">
                <td>TOTAL:</td>
                <td><?php echo $total;?></TD>
                </tr>	
</table>
</html>
