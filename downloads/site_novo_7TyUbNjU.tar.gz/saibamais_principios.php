<?php

    $f = trim($_GET['f']);

    include("Mobile_Detect/Mobile_Detect.php");
    $detect = new Mobile_Detect();

    $pagina = 'saibamais';

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8 lt-ie7" lang="pt-BR"> <![endif]-->
<!--[if IE 7]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8" lang="pt-BR"> <![endif]-->
<!--[if IE 8]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9" lang="pt-BR"> <![endif]-->
<!--[if gt IE 8]><!--> <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js" lang="pt-BR"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>NOVO | Princípios</title>
        <link rel="image_src" href="http://www.novo.org.br/logo.jpg" />
        <meta name="description" content="Conheça os princípios do NOVO.">
        <meta name="viewport" content="width=1024">
        <meta name="author" content="Partido NOVO - Gestão e Cidadania" /> 
        <meta name="robots" content="index, follow" />
        <meta name="revisit" content="3 days" /> 
        <meta property="og:title" content="Partido NOVO - Princípios" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="http://www.novo.org.br/logo.jpg" />
        <meta property="og:url" content="http://www.novo.org.br/principios" />
        <meta property="og:description" content="Conheça os princípios do NOVO." />

        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">

        <!--[if IE]>
        <style>
            #topo_variavel div img {position: relative; top: -20px;}
        </style>
        <![endif]-->

        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
    <div id="fb-root"></div>
		<script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

        <div id="main" style="width: 100%; background: url(img/bg_textura_azul.jpg);">
            <header style="width: 100%; background: url(img/bg_textura_branco_interna.jpg);">
                <div id="header_in" style="width: 950px; margin: 0 auto;">
                    <nav>
                        <?php include("includes/menu.php"); ?>
                    </nav>
                    <div id="topo_fixo" style="width: 950px; height: 122px; position: relative; z-index: 9990;">
                        <a href="index.php"><img src="img/logo.png" alt="Partido NOVO | Gestão e Cidadania" border="0" /></a>

                        <div id="redessociais" style="float: right; margin-right: 4px;">
                            <div class="fb-like" data-href="http://facebook.com/partidonovo" data-send="false" data-width="290" data-show-faces="false" style="height: 30px; display: block; margin-bottom: 7px;"></div>
                            
                            <!--
                            <a href="http://www.twitter.com/desafionovo500" target="_blank"><img src="img/bt_twitter.png" alt="Partido NOVO | Twitter" style="float: right;" border="0" /><a/>
                            <a href="http://www.facebook.com/partidonovo" target="_blank"><img src="img/bt_facebook.png" alt="Partido NOVO | Facebook" style="float: right; margin-right: 6px;" border="0" /></a>
                            -->
                        </div>
                    </div>
                    <div style="clear: both;"><!-- --></div>
                    <div id="topo_variavel" style="width: 950px; height: 409px; margin: -51px 0 0 0;">
                        <div style="width: 950px; height: 409px;">
                            <img src="img/saibamais/topo.png" alt="Conheça os princípios, programas e estatuto do NOVO, e tire suas dúvidas." style="display: block;" />
                        </div>
                    </div>
                </div>
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
            </header>

            <div id="assine" style="width: 100%; height: 104px; background: url(img/bg_assine.png); margin-bottom: 7px;">
                <div id="assine_in" style="width: 950px; height: 61px; margin: 0 auto;"></div>
            </div>

            <a id="indice" href="#"><!-- --></a>

            <article id="pagina-saiba-mais-principios" style="width: 950px; margin: 0 auto 65px auto;">
                <h1 style="width: 950px; height: 39px; background: url(img/saibamais/tit_saibamais.png) top center no-repeat; margin: 0 auto 47px auto; text-indent: -9999px;">Saiba Mais</h1>
                
                <div style="width: 950px; height: 47px; background: url(img/corner_top.png) top center no-repeat;"></div>
                <section style="width: 890px; padding: 21px 30px 18px 30px; background-color: #f4f0e7;">
        
                    <div style="width: 890px; margin-bottom: 62px;">
                        <div style="width: 890px; margin-bottom: 20px; float: left;">
                            <div style="width: 284px; height: 83px; margin-left: 156px; margin-right: 5px; float: left;">
                                <a href="saibamais_principios.php#indice"><img src="img/saibamais/bot_principios_selecionado.png" alt="Princípios" border="0" /></a>
                            </div>
                            <div style="width: 284px; height: 83px; margin-left: 5px; float: left;">
                                <a href="saibamais_programa.php#indice"><img src="img/saibamais/bot_programa.png" alt="Programa" border="0" /></a>
                            </div>
                        </div>
                        <div style="width: 890px; float: left;">
                            <div style="width: 283px; height: 83px; margin-left: 10.5px; margin-right: 5px; float: left;">
                                <a href="saibamais_estatuto.php#indice"><img src="img/saibamais/bot_estatuto.png" alt="Estatuto" border="0" /></a>
                            </div>
                            <div style="width: 283px; height: 83px; margin: 0 5px; float: left;">
                                <a href="saibamais.php#indice"><img src="img/saibamais/bot_perguntasfrequentes.png" alt="Perguntas Frequentes" border="0" /></a>
                            </div>
                            <div style="width: 283px; height: 83px; margin-left: 5px; float: left;">
                                <a href="saibamais_namidia.php#indice"><img src="img/saibamais/bot_novonamidia.png" alt="NOVO na mídia" border="0" /></a>
                            </div>
                        </div>
                        <div style="clear: both;"></div>
                    </div>

                    <h2 style="font-family: Arial; width: 890px; text-align: center; font-size: 30px; line-height: 18px; color: #464646; margin-bottom: 42px;"><strong>PRINCÍPIOS DO NOVO</strong></h2>
                    
                    <p>Com o intuito de colocarmos em prática os princípios abaixo descritos, nasce o NOVO.<br /><br />

                    Acreditamos que a vida em sociedade é necessariamente política. Pode-se escolher entre ser governante ou ser governado. Contudo, não se pode fugir da organização política da sociedade nem deixar de usufruir ou sofrer as conseqüências dela.<br /><br />

                    Entendemos que um Estado Democrático que defenda os direitos individuais, a liberdade de expressão, a transparência, a excelência da administração pública e o desenvolvimento sócio-econômico sustentável é a forma adequada de construirmos uma sociedade justa e sustentável.<br /><br />

                    Os recursos do Estado são finitos e governar é definir prioridades e exige uma gestão eficiente. É possível buscar a dignidade do governante e do governado, com direitos e deveres recíprocos e recíprocas prestações de contas.<br /><br />

                    A eficiente administração separa o patrimônio público do privado, respeita a ambos e distribui os respectivos benefícios com medidas de honestidade e justiça. E, sobretudo, consciente de que os impostos arrecadados custam caro à sociedade, concebe e pratica o governo de forma planejada, a curto, médio e longo prazo, valendo-se do desenvolvimento do conhecimento humano para buscar solução adequada e a custo razoável para os principais desafios. Gestão eficiente só se faz com gente eficiente.<br /><br />

                    Numa sociedade organizada e democrática, a união de cidadãos em um partido político é a forma mais adequada para trabalhar-se em prol das futuras gerações. Entendemos os cargos eletivos como oportunidades de prestação de serviço público e não como carreira profissional. Cremos que essa oportunidade deva existir sempre, para todos os cidadãos vocacionados cujo objetivo seja o de construir um presente digno e um futuro melhor.<br /><br />

                    Entendemos que não basta candidatar-se e eleger-se. Para governar com eficiência também é preciso ter o suporte da sociedade e do partido político.<br /><br />

                    <a href="downloads/Principios.pdf" target="_blank">Download dos Princípios em PDF</a></p>

                </section>
                <div style="width: 950px; height: 25px; background: url(img/corner_bottom.png) top center no-repeat;"></div>

                <div style="clear: both;"></div>
            </article>

            <footer style="width: 100%; height: 71px; background: url(img/bg_rodape.jpg);">
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
                <div id="footer_in" style="width: 927px; margin: 0 auto; padding: 21px 0 0 23px;">
                    <img src="img/logo_rodape.png" alt="Partido NOVO | Gestão e Cidadania" />

                    <a href="http://www.zaw.com.br/" target="_blank"><img src="img/zaw.png" alt="ZAW" style="float: right; margin-left: 40px; position: relative; bottom: -6px;" border="0" /></a>

                    <nav style="float: right;">
                        <ul>
                            <li><a href="javascript: return false;" onclick="$('body,html').animate({scrollTop: 0}, 800); return false;">De volta ao topo</a></li>
                        </ul>
                    </nav>
                </div>
            </footer>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.0.min.js"><\/script>')</script>

        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
        
        <?php if($detect->isMobile()) : ?>
        <script src="js/menu_mobile.js"></script>
        <?php else : ?>
        <script src="js/menu.js"></script>
        <?php endif; ?>

        <?php if(isset($f) && !empty($f)) : ?>
        <script>
        (function() {

            location.href= '#<?php echo $f; ?>';

        }());
        </script>
        <?php endif; ?>

        <script type="text/javascript">
          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-21651021-1']);
          _gaq.push(['_trackPageview']);

          (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();
        </script>
    </body>
</html>
