<?php

    $f = trim($_GET['f']);

    include("Mobile_Detect/Mobile_Detect.php");
    $detect = new Mobile_Detect();

    $pagina = 'comoparticipar';

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8 lt-ie7" lang="pt-BR"> <![endif]-->
<!--[if IE 7]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8" lang="pt-BR"> <![endif]-->
<!--[if IE 8]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9" lang="pt-BR"> <![endif]-->
<!--[if gt IE 8]><!--> <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js" lang="pt-BR"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Participe do NOVO</title>
        <link rel="image_src" href="http://www.novo.org.br/logo.jpg" />
        <meta name="description" content="Assine sua ficha de apoio! Participe da criação do NOVO.">
        <meta name="viewport" content="width=1024">
        <meta name="author" content="Partido NOVO - Gestão e Cidadania" /> 
        <meta name="robots" content="index, follow" />
        <meta name="revisit" content="3 days" /> 
        <meta property="og:title" content="Partido NOVO - Participe do NOVO" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="http://www.novo.org.br/logo.jpg" />
        <meta property="og:url" content="http://www.novo.org.br/participe" />
        <meta property="og:description" content="Assine sua ficha de apoio! Participe da criação do NOVO." />

        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">

        <!--[if IE]>
        <style>
            #topo_variavel div img {position: relative; top: -20px;}
        </style>
        <![endif]-->

        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
<div id="fb-root"></div>

	<script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

        <div id="main" style="width: 100%; background: url(img/bg_textura_azul.jpg);">
            <header style="width: 100%; background: url(img/bg_textura_branco_interna.jpg);">
                <div id="header_in" style="width: 950px; margin: 0 auto;">
                    <nav>
                        <?php include("includes/menu.php"); ?>
                    </nav>
                    <div id="topo_fixo" style="width: 950px; height: 122px; position: relative; z-index: 9990;">
                        <a href="index.php"><img src="img/logo.png" alt="Partido NOVO | Gestão e Cidadania" border="0" /></a>

                        <div id="redessociais" style="float: right; margin-right: 4px;">
                            <div class="fb-like" data-href="http://facebook.com/partidonovo" data-send="false" data-width="290" data-show-faces="false" style="height: 30px; display: block; margin-bottom: 7px;"></div>
                            
                            <!--
                            <a href="http://www.twitter.com/desafionovo500" target="_blank"><img src="img/bt_twitter.png" alt="Partido NOVO | Twitter" style="float: right;" border="0" /><a/>
                            <a href="http://www.facebook.com/partidonovo" target="_blank"><img src="img/bt_facebook.png" alt="Partido NOVO | Facebook" style="float: right; margin-right: 6px;" border="0" /></a>
                            -->
                        </div>
                    </div>
                    <div style="clear: both;"><!-- --></div>
                    <div id="topo_variavel" style="width: 950px; height: 409px; margin: -51px 0 0 0;">
                        <div style="width: 950px; height: 409px;">
                            <img src="img/comoparticipar/topo2.png" alt="Quanto mais assinaturas, mais rápido nos tornaremos realidade para poder trabalhar por um Brasil melhor. Divulgue o NOVO entre seus amigos, convide-os a fazer parte desse movimento." style="display: block;" />
                        </div>
                    </div>
                </div>
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
            </header>

          <div id="assine" style="width: 100%; height: 104px; background: url(img/bg_assine.png); margin-bottom: 7px;">
                <div id="assine_in" style="width: 950px; height: 61px; margin: 0 auto;"></div>
            </div>

            <article style="width: 950px; margin: 0 auto 65px auto;">
                <h2 style="width: 950px; height: 54px; background: url(img/comoparticipar/tit_participedonovo.png) top center no-repeat; margin: 0 auto 47px auto; text-indent: -9999px;">Participe do NOVO</h2>
                
                <div style="width: 950px; height: 47px; background: url(img/corner_top.png) top center no-repeat;"></div>
                <section style="width: 890px; padding: 0 30px 18px 30px; background-color: #f4f0e7;">

                    <h1 style="width: 890px; font-family: Arial; font-size: 30px; color: #464646; text-transform: uppercase; margin-bottom: 46px; text-align: center;"><strong>Como Participar</strong></h1>
                    
                    <img src="img/comoparticipar/fig1.png" alt="Seja a mudança que você deseja ver no Brasil." style="margin-left: 11px; float: left;" />

                  <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; margin-left: 40px; float: left; width: 567px;">Após a fundação, o NOVO passou por uma árdua etapa exigida pela legislação para a formação de um partido político. <strong>Nesta etapa coletamos aproximadamente 1 milhão de fichas  para conseguirmos o reconhecimento  de 492 mil, assinadas  por eleitores que apoiam a criação do NOVO. </strong></p>
            <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; margin-left: 40px; float: left; width: 567px;">Essas fichas foram separadas e entregues nos cartórios de cada eleitor, para conferência uma à uma.<br />
                      <br />

                    <strong>Obrigado a todos que contribuiram nesse processo.</strong><br />
</p>
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; margin-left: 40px; float: left; width: 567px;">	Tão logo o registro seja concedido pelo TSE <strong>poderemos ter filiados</strong> e participar de eleições.</p>
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; margin-left: 40px; float: left; width: 567px;">&nbsp;</p>
                    
                  <div style="clear: both;"></div>

                    <hr style="width: 890px; border: none; border-top: #bcb8ae solid 1px; border-bottom: #ffffff solid 1px; margin: 0 0 50px 0;" />

                    <a id="ficha" href="#"><!-- --></a>

                    <h2 style="font-family: Arial; font-size: 24px; color: #464646; margin-bottom: 24px;"><strong>DIVULGUE O NOVO</strong></h2>

                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;"><span style="font-family: Arial; font-size: 18px; color: #464646;"><strong>No momento, a melhor contribuição que você pode dar é divulgar o NOVO e participar dos debates.</strong></span></p>
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;"><br />

                    <span style="font-family: Arial; font-size: 18px; color: #464646;">Nesta nova fase, teremos um grande trabalho para expandir grupo de divulgação e atingir mais pessoas com as ideias do NOVO. </span></p>
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;">&nbsp;</p>
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;"><span style="font-family: Arial; font-size: 18px; color: #464646;"><strong>Lembre-se que o NOVO é um partido de ideias.</strong></span></p>
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;"><br />

                    <strong>Como ajudar:</strong><br /><br />
                    <strong>- </strong>
                    Siga a página do NOVO no <a href="http://fb.com/partidonovo">facebook</a>.</p>
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;">- Compatilhe os posts do novo e participe dos comentários.</p>
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;">- Fale sobre o NOVO no seu dia-a-dia, com as pessoas que você conhece. Seja um entusiasta!</p>
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;">- Organize grupos na sua cidade, bairro, comunidade. Faça reuniões com as pessoas para apresentar as ideias do NOVO. Se precisar de ajuda para organizar o evento,  <a href="fale.php">fale conosco</a>.</p>
                  <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;">&nbsp;</p>
                <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px;"><strong></strong>	<!--a href="https://apps.facebook.com/partido_novo/" target="_blank"><img src="img/facebook.jpg" alt="" style="margin-right: 20px; margin-top: 52px; float: left;" border="0" /></a>

                    <div style="float: right; margin-top: 52px;">

                        <h2 style="font-face: Arial; font-size: 24px; color: #f68428; margin-bottom: 27px;">Desafio NOVO 500</h2>

                        <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; float: left; width: 690px; margin: 0;">Com o objetivo de facilitar o preenchimento da Ficha de Apoio, criamos no Facebook o <a href="https://apps.facebook.com/partido_novo/" target="_blank" style="color: #116d74; font-weight: bold;">aplicativo Desafio NOVO 500</a>. Através desse aplicativo você pode preencher sua ficha online, e imprimir, assinar e enviar pelo Correio - o porte é pago.<br /><br />

                        Caso não disponha de impressora no momento, você pode salvar para imprimir posteriormente.</p>

                    </div--><span style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; margin: 0 0 70px 0; display: block;"><span style="font-family: Arial; font-size: 18px; color: #464646;"><strong>Faça a diferença.</strong></span><br />
                        <br />
Divulgue o NOVO entre seus amigos, convide-os a fazer parte desse movimento.</span></p>
                  <div style="clear: both;"><!-- --></div>

                    <hr style="width: 890px; border: none; border-top: #bcb8ae solid 1px; border-bottom: #ffffff solid 1px; margin: 50px 0;" />
                    <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; margin: 0 0 70px 0; display: block;">&nbsp;</p>

                    <div style="width: 890px;">
                        <div style="width: 321px; height: 192px; border: none; border-right: #f68428 dotted 3px; float: left;">
                            <a href="http://www.novo.org.br/CartaNOVO.pdf" target="_blank"><img src="img/icone_cartaapresentacao.png" alt="" style="margin-right: 20px; float: left;" border="0" /></a>

                            <h3 style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; width: 243px; float: left;">CARTA DE APRESENTAÇÃO</h3>

                            <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; display: inline-block; width: 243px;">Quer apresentar o NOVO aos seus amigos? Já fizemos a carta, é só mandar para os seus contatos.</p>
                            
                            <form>
                                <label style="width: 310px; height: 22px; font-size: 15px;">Copie o link e compartilhe:</label><br />
                                <textarea id="link" style="width: 302px; height: 41px; resize: none; padding: 3px; font-size: 14px;" readonly />http://novo.org.br/CartaNOVO.pdf</textarea>
                            </form>

                  </div>
                        <div style="width: 565px; height: 192px; float: left;">
                            <a href="http://www.facebook.com/partidonovo" target="_blank"><img src="img/icone_facebook.png" alt="" style="margin-left: 23px; margin-right: 29px; float: left;" border="0" /></a>

                            <h3 style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; width: 320px; float: left;">FACEBOOK</h3>

                            <p style="font-family: Arial; font-size: 15px; color: #464646; line-height: 20px; display: inline-block; width: 320px;">Através da nossa página no Facebook mantemos um debate aberto sobre assuntos atuais, divulgamos nossas ideias e propostas. Acesse a página e faça parte deste movimento. Queremos ouvir você!</p>
                        </div>
                        <div style="clear: both;"></div>
                    </div>

                </section>
                <div style="width: 950px; height: 25px; background: url(img/corner_bottom.png) top center no-repeat;"></div>

                <div style="clear: both;"></div>
            </article>

            <footer style="width: 100%; height: 71px; background: url(img/bg_rodape.jpg);">
      <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
                <div id="footer_in" style="width: 927px; margin: 0 auto; padding: 21px 0 0 23px;">
                    <img src="img/logo_rodape.png" alt="Partido NOVO | Gestão e Cidadania" />

                    <a href="http://www.zaw.com.br/" target="_blank"><img src="img/zaw.png" alt="ZAW" style="float: right; margin-left: 40px; position: relative; bottom: -6px;" border="0" /></a>

                    <nav style="float: right;">
                        <ul>
                            <li><a href="javascript: return false;" onclick="$('body,html').animate({scrollTop: 0}, 800); return false;">De volta ao topo</a></li>
                        </ul>
                    </nav>
                </div>
            </footer>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.0.min.js"><\/script>')</script>

        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>

        <?php if($detect->isMobile()) : ?>
        <script src="js/menu_mobile.js"></script>
        <?php else : ?>
        <script src="js/menu.js"></script>
        <?php endif; ?>

        <script>
        (function() {

            var ua = navigator.userAgent,
            event = (ua.match(/iPad/i)) ? "touchstart" : "click";

            $("#link").bind(event, function() {
                
                $(this).select();

            });

        }());
        </script>

        <?php if(isset($f) && !empty($f)) : ?>
        <script>
        (function() {

            location.href= '#<?php echo $f; ?>';

        }());
        </script>
        <?php endif; ?>

        <script type="text/javascript">
          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-21651021-1']);
          _gaq.push(['_trackPageview']);

          (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();
        </script>
    </body>
</html>
