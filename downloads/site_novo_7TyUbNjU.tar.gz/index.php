<?php

    $f = trim($_GET['f']);
    
    include("Mobile_Detect/Mobile_Detect.php");
    $detect = new Mobile_Detect();

    $pagina = '';

    $membros = array(array('biancabacha', 1),
                     array('christianlohbauer', 1),
                     array('claudiobarra', 1),
                     array('elisonamaral', 1),
                     array('erichtavares', 1),
                     array('fabioribeiro', 1),
                     array('flaviagoulart', 1),
                     array('josehumberto', 1),
                     array('joseluiz', 1),
                     array('luisclaudio', 1),
                     array('marcosalcantara', 1),
                     array('mariabeatriz', 1),
                     array('marianaamoedo', 1),
                     array('massaohatae', 1),
                     array('paulacorrente', 1),
                     array('raphaellaburti', 1),
                     array('renatonalini', 1),
                     array('ricardopelucio', 1));

?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8 lt-ie7" lang="pt-BR"> <![endif]-->
<!--[if IE 7]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9 lt-ie8" lang="pt-BR"> <![endif]-->
<!--[if IE 8]>         <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js lt-ie9" lang="pt-BR"> <![endif]-->
<!--[if gt IE 8]><!--> <html xmlns:og="http://opengraphprotocol.org/schema/" class="no-js" lang="pt-BR"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>NOVO | Gestão e Cidadania | partido político</title>
        <link rel="image_src" href="http://www.novo.org.br/logo.jpg" />
        <meta name="description" content="Conheça essa ideia. O Brasil precisa do NOVO. O NOVO precisa de você. Participe!">
        <meta name="viewport" content="width=1024">
        <meta name="author" content="Partido NOVO - Gestão e Cidadania" />
        <meta name="robots" content="index, follow" />
        <meta name="revisit" content="3 days" /> 
        <meta property="og:title" content="Partido NOVO | Gestão e Cidadania" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="http://www.novo.org.br/logo.jpg" />
        <meta property="og:url" content="http://www.novo.org.br" />
        <meta property="og:description" content="Conheça essa ideia. O Brasil precisa do NOVO. O NOVO precisa de você. Participe!" />

        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">

        <!--[if IE]>
        <style>
            nav {position: relative; z-index: 10010;}
            #slider {position: relative; top: -116px;}
        </style>
        <![endif]--> 

		<script language="JavaScript" type="text/javascript" src="js/MascaraValidacao.js"></script> 
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
<div id="fb-root"></div>
		<script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

        <div id="main" style="width: 100%; background: url(img/bg_textura_azul.jpg);">
            <header style="width: 100%; background: url(img/bg_textura_branco.jpg);">
                <div id="header_in" style="width: 950px; margin: 0 auto;">
                    <nav>
                        <?php include("includes/menu.php"); ?>
                    </nav>
                    <div id="topo_fixo" style="width: 950px; height: 122px; position: relative; z-index: 9990;">
                        <a href="index.php"><img src="img/logo.png" alt="Partido NOVO | Gestão e Cidadania" border="0" /></a>

                        <div id="redessociais" style="float: right; margin-right: 4px;">
                            <div class="fb-like" data-href="http://facebook.com/partidonovo" data-send="false" data-width="290" data-show-faces="false" style="height: 30px; display: block; margin-bottom: 7px;"></div>
                            
                            <a href="http://www.twitter.com/desafionovo500" target="_blank"><img src="img/bt_twitter.png" alt="Twitter" style="float: right;" border="0" /><a/>
                            <a href="http://www.facebook.com/partidonovo" target="_blank"><img src="img/bt_facebook.png" alt="Facebook" style="float: right; margin-right: 6px;" border="0" /></a><a href="https://plus.google.com/108121808198208136050" target="_blank"><img src="img/bt_plus.png" alt="Google+" style="float: right; margin-right: 6px;" border="0" rel="publisher"/></a>
                        </div>
                    </div>
                    <div style="clear: both;"><!-- --></div>
                    <div id="topo_variavel" style="width: 950px; height: 505px; margin: -147px 0 0 0;">
                        <div id="slider" style="width: 950px; height: 505px;">
                            <?php $n = rand(0, 15); ?>
                            <img src="img/home/slide_<?php echo $membros[$n][0]; ?>.png" alt="" />
                        </div>
                        <div id="tag" style="width: 331px; height: 143px; margin-top: -107px; position: relative; z-index: 9999;">
                            <?php $n = rand(0, 15); ?>
                            <img src="img/home/tag_<?php echo $membros[$n][0]; ?>.png" alt="" style="cursor: pointer;" onclick="$('#slider img').attr('src', $(this).attr('src').replace('tag_', 'slide_'));" />
                        </div>
                    </div>
                </div>
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
            </header>

            <div id="assine" style="width: 100%; height: 104px; background: url(img/bg_assine.png);">
                <div id="assine_in" style="width: 950px; height: 61px; margin: 0 auto;"></div>
            </div>

            <section style="width: 950px; margin: 0 auto 37px auto;">
                <h2 style="width: 950px; height: 57px; background: url(img/home/tit_video.png) top center no-repeat; margin: 0 auto 24px auto; text-indent: -9999px;">Participe do NOVO</h2>
                
                <div style="width: 800px; height: 450px; margin: 0 auto; background-color: #f68428;">
                    <iframe src="http://player.vimeo.com/video/65073569?title=0&amp;byline=0&amp;portrait=0&amp;color=f68428" width="800" height="450" frameborder="0" style="margin: -9px 0 0 -9px;" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
                </div>
                <div style="clear: both;"></div>
            </section>

            <a id="ideais" href="#"><!-- --></a>

            <section style="width: 950px; margin: 0 auto 70px auto;">
                <h1 style="width: 950px; height: 99px; background: url(img/home/tit_valores.png) top center no-repeat; margin: 0 auto 30px auto; text-indent: -9999px;">Valores</h1>
                
                <div id="modal_principal" style="float: left;">
                    <div style="width: 228px; height: 176px; float: left; margin: 0 5px 5px 0; background-color: #de7823; border: #dc6908 solid 1px; cursor: pointer;" onclick="$(this).parent().hide(); $('#modal1').show();">
                        <h2 style="font-family: 'UniversLTStd-LightCn', Arial; font-size: 24px; color: #ffffff; font-weight: normal; text-transform: uppercase; text-align: center; line-height: 25px; margin-top: 53px;"><strong style="font-family: 'UniversLTStd-BoldCn'; font-weight: normal;">Indivíduo<br />como agente<br />de mudanças</strong></h2>
                    </div>
                    <div style="width: 228px; height: 176px; float: left; margin: 0 5px 5px 5px; background-color: #116d74; border: #0c6872 solid 1px; cursor: pointer;" onclick="$(this).parent().hide(); $('#modal2').show();">
                        <h2 style="font-family: 'UniversLTStd-LightCn', Arial; font-size: 24px; color: #ffffff; font-weight: normal; text-transform: uppercase; text-align: center; line-height: 25px; margin-top: 64px;"><strong style="font-family: 'UniversLTStd-BoldCn'; font-weight: normal;">Visão de<br />longo prazo</strong></h2>
                    </div>
                    <div style="width: 228px; height: 176px; float: left; margin: 0 5px 5px 5px; background-color: #de7823; border: #dc6908 solid 1px; cursor: pointer;" onclick="$(this).parent().hide(); $('#modal3').show();">
                        <h2 style="font-family: 'UniversLTStd-LightCn', Arial; font-size: 24px; color: #ffffff; font-weight: normal; text-transform: uppercase; text-align: center; line-height: 25px; margin-top: 53px;"><strong style="font-family: 'UniversLTStd-BoldCn'; font-weight: normal;">Liberdades<br />individuais</strong> com<br />responsabilidade</h2>
                    </div>
                    <div style="width: 228px; height: 176px; float: left; margin: 0 0 5px 5px; background-color: #116d74; border: #0c6872 solid 1px; cursor: pointer;" onclick="$(this).parent().hide(); $('#modal4').show();">
                        <h2 style="font-family: 'UniversLTStd-LightCn', Arial; font-size: 24px; color: #ffffff; font-weight: normal; text-transform: uppercase; text-align: center; line-height: 25px; margin-top: 77px;"><strong style="font-family: 'UniversLTStd-BoldCn'; font-weight: normal;">Excelência</strong></h2>
                    </div>
                    <div style="width: 228px; height: 176px; float: left; margin: 5px 5px 0 0; background-color: #116d74; border: #0c6872 solid 1px; cursor: pointer;" onclick="$(this).parent().hide(); $('#modal5').show();">
                        <h2 style="font-family: 'UniversLTStd-LightCn', Arial; font-size: 24px; color: #ffffff; font-weight: normal; text-transform: uppercase; text-align: center; line-height: 25px; margin-top: 53px;"><strong style="font-family: 'UniversLTStd-BoldCn'; font-weight: normal;">Indivíduo</strong> como<br />único <strong style="font-family: 'UniversLTStd-BoldCn'; font-weight: normal;">criador<br />de riquezas</strong></h2>
                    </div>
                    <div style="width: 228px; height: 176px; float: left; margin: 5px 5px 0 5px; background-color: #de7823; border: #dc6908 solid 1px; cursor: pointer;" onclick="$(this).parent().hide(); $('#modal6').show();">
                        <h2 style="font-family: 'UniversLTStd-LightCn', Arial; font-size: 24px; color: #ffffff; font-weight: normal; text-transform: uppercase; text-align: center; line-height: 25px; margin-top: 64px;"><strong style="font-family: 'UniversLTStd-BoldCn'; font-weight: normal;">Todos são iguais</strong><br />perante a lei</h2>
                    </div>
                    <div style="width: 228px; height: 176px; float: left; margin: 5px 5px 0 5px; background-color: #116d74; border: #0c6872 solid 1px; cursor: pointer;" onclick="$(this).parent().hide(); $('#modal7').show();">
                        <h2 style="font-family: 'UniversLTStd-LightCn', Arial; font-size: 24px; color: #ffffff; font-weight: normal; text-transform: uppercase; text-align: center; line-height: 25px; margin-top: 64px;"><strong style="font-family: 'UniversLTStd-BoldCn'; font-weight: normal;">Aplicação<br />rigorosa da Lei</strong></h2>
                    </div>
                    <div style="width: 228px; height: 176px; float: left; margin: 5px 0 0 5px; background-color: #de7823; border: #dc6908 solid 1px; cursor: pointer;" onclick="$(this).parent().hide(); $('#modal8').show();">
                        <h2 style="font-family: 'UniversLTStd-LightCn', Arial; font-size: 24px; color: #ffffff; font-weight: normal; text-transform: uppercase; text-align: center; line-height: 25px; margin-top: 77px;"><strong style="font-family: 'UniversLTStd-BoldCn'; font-weight: normal;">Livre mercado</strong></h2>
                    </div>
                </div>
                
                <div id="modal1" style="position: relative; width: 839px; height: 329px; float: left; background: url(img/home/bg_modal.jpg) top center no-repeat; display: none; padding: 37px 55.5px 0 55.5px;">                    

                    <a onclick="$(this).parent().hide(); $('#modal8').show();" style="position: absolute; top: 58px; left: 56px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_voltar.png"></a>
                    <a onclick="$(this).parent().hide(); $('#modal2').show();" style="position: absolute; top: 58px; right: 55px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_avancar.png"></a>

                    <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 42px; color: #17a0aa; width: 839px; height: 127px; text-align: center; border-bottom: #f68428 dotted 3px; font-weight: normal; line-height: 43px; text-transform: uppercase;">Indivíduo como<br />agente de mudanças</h2>

                    <p style="margin: 41px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #363636; line-height: 28px;">As mudanças e reformas que queremos promover têm o indivíduo, através da sua atuação e do voto consciente, como principal responsável. O direito de criticar deve ter como contrapartida o dever de participar.</p>
                    
                    <a onclick="fechaModal(this);" style="position: absolute; bottom: 23px; right: 24px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_fechar.png"></a>

                </div>

                <div id="modal2" style="position: relative; width: 839px; height: 308px; float: left; background: url(img/home/bg_modal.jpg) top center no-repeat; display: none; padding: 58px 55.5px 0 55.5px;">                    

                    <a onclick="$(this).parent().hide(); $('#modal1').show();" style="position: absolute; top: 58px; left: 56px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_voltar.png"></a>
                    <a onclick="$(this).parent().hide(); $('#modal3').show();" style="position: absolute; top: 58px; right: 55px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_avancar.png"></a>

                    <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 42px; color: #17a0aa; width: 839px; height: 105px; text-align: center; border-bottom: #f68428 dotted 3px; font-weight: normal; line-height: 43px; text-transform: uppercase;">Visão de longo prazo</h2>

                    <p style="margin: 41px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #363636; line-height: 28px;">O NOVO acredita que é necessário resgatar a cultura e o pensamento de longo prazo na administração pública. As oportunidades, desaﬁos e vocações do País devem ser avaliados por uma perspectiva de tempo que ultrapasse as próximas eleições. É dever do gestor público não onerar as futuras gerações.</p>
                    
                    <a onclick="fechaModal(this)" style="position: absolute; bottom: 23px; right: 24px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_fechar.png"></a>

                </div>

                <div id="modal3" style="position: relative; width: 839px; height: 329px; float: left; background: url(img/home/bg_modal.jpg) top center no-repeat; display: none; padding: 37px 55.5px 0 55.5px;">                    

                    <a onclick="$(this).parent().hide(); $('#modal2').show();" style="position: absolute; top: 58px; left: 56px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_voltar.png"></a>
                    <a onclick="$(this).parent().hide(); $('#modal4').show();" style="position: absolute; top: 58px; right: 55px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_avancar.png"></a>

                    <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 42px; color: #17a0aa; width: 839px; height: 127px; text-align: center; border-bottom: #f68428 dotted 3px; font-weight: normal; line-height: 43px; text-transform: uppercase;">Liberdades individuais<br />com responsabilidade</h2>

                    <p style="margin: 41px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #363636; line-height: 28px;">Acreditamos no valor fundamental das liberdades individuais, incluindo direitos e deveres.</p>
                    
                    <a onclick="fechaModal(this)" style="position: absolute; bottom: 23px; right: 24px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_fechar.png"></a>

                </div>

                <div id="modal4" style="position: relative; width: 839px; height: 308px; float: left; background: url(img/home/bg_modal.jpg) top center no-repeat; display: none; padding: 58px 55.5px 0 55.5px;">                    

                    <a onclick="$(this).parent().hide(); $('#modal3').show();" style="position: absolute; top: 58px; left: 56px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_voltar.png"></a>
                    <a onclick="$(this).parent().hide(); $('#modal5').show();" style="position: absolute; top: 58px; right: 55px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_avancar.png"></a>

                    <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 42px; color: #17a0aa; width: 839px; height: 105px; text-align: center; border-bottom: #f68428 dotted 3px; font-weight: normal; line-height: 43px; text-transform: uppercase;">Excelência</h2>

                    <p style="margin: 41px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #363636; line-height: 28px;">O NOVO tem compromisso com a qualidade em todas as esferas do serviço público. O partido acredita que a recompensa desse comportamento é uma sociedade justa e próspera, que valoriza o sucesso, o esforço e o mérito.</p>
                    
                    <a onclick="fechaModal(this)" style="position: absolute; bottom: 23px; right: 24px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_fechar.png"></a>

                </div>

                <div id="modal5" style="position: relative; width: 839px; height: 329px; float: left; background: url(img/home/bg_modal.jpg) top center no-repeat; display: none; padding: 37px 55.5px 0 55.5px;">                    

                    <a onclick="$(this).parent().hide(); $('#modal4').show();" style="position: absolute; top: 58px; left: 56px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_voltar.png"></a>
                    <a onclick="$(this).parent().hide(); $('#modal6').show();" style="position: absolute; top: 58px; right: 55px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_avancar.png"></a>

                    <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 42px; color: #17a0aa; width: 839px; height: 127px; text-align: center; border-bottom: #f68428 dotted 3px; font-weight: normal; line-height: 43px; text-transform: uppercase;">Indivíduo como único<br />criador de riquezas</h2>

                    <p style="margin: 41px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #363636; line-height: 28px;">Os recursos do Estado serão sempre oriundos dos impostos pagos pelos indivíduos. Os serviços públicos ofertados nunca são gratuitos.</p>
                    
                    <a onclick="fechaModal(this)" style="position: absolute; bottom: 23px; right: 24px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_fechar.png"></a>

                </div>

                <div id="modal6" style="position: relative; width: 839px; height: 308px; float: left; background: url(img/home/bg_modal.jpg) top center no-repeat; display: none; padding: 58px 55.5px 0 55.5px;">                    
                    
                    <a onclick="$(this).parent().hide(); $('#modal5').show();" style="position: absolute; top: 58px; left: 56px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_voltar.png"></a>
                    <a onclick="$(this).parent().hide(); $('#modal7').show();" style="position: absolute; top: 58px; right: 55px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_avancar.png"></a>

                    <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 42px; color: #17a0aa; width: 839px; height: 105px; text-align: center; border-bottom: #f68428 dotted 3px; font-weight: normal; line-height: 43px; text-transform: uppercase;">Todos são iguais perante a lei</h2>

                    <p style="margin: 41px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #363636; line-height: 28px;">O NOVO defende com vigor o princípio da igualdade. Respeitamos uma hierarquia das normas e de um sistema institucional no qual todo e qualquer indivíduo é submetido ao direito e às leis de forma isonômica, sem privilégios.</p>
                    
                    <a onclick="fechaModal(this);" style="position: absolute; bottom: 23px; right: 24px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_fechar.png"></a>

                </div>

                <div id="modal7" style="position: relative; width: 839px; height: 308px; float: left; background: url(img/home/bg_modal.jpg) top center no-repeat; display: none; padding: 58px 55.5px 0 55.5px;">                    

                    <a onclick="$(this).parent().hide(); $('#modal6').show();" style="position: absolute; top: 58px; left: 56px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_voltar.png"></a>
                    <a onclick="$(this).parent().hide(); $('#modal8').show();" style="position: absolute; top: 58px; right: 55px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_avancar.png"></a>

                    <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 42px; color: #17a0aa; width: 839px; height: 105px; text-align: center; border-bottom: #f68428 dotted 3px; font-weight: normal; line-height: 43px; text-transform: uppercase;">Aplicação Rigorosa da Lei</h2>

                    <p style="margin: 41px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #363636; line-height: 28px;">A impunidade não pode ser tolerada. O NOVO defende a aplicação rápida e eficiente das penas.</p>
                    
                    <a onclick="fechaModal(this);" style="position: absolute; bottom: 23px; right: 24px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_fechar.png"></a>

                </div>

                <div id="modal8" style="position: relative; width: 839px; height: 308px; float: left; background: url(img/home/bg_modal.jpg) top center no-repeat; display: none; padding: 58px 55.5px 0 55.5px;">                    
                    
                    <a onclick="$(this).parent().hide(); $('#modal7').show();" style="position: absolute; top: 58px; left: 56px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_voltar.png"></a>
                    <a onclick="$(this).parent().hide(); $('#modal1').show();" style="position: absolute; top: 58px; right: 55px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_avancar.png"></a>

                    <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 42px; color: #17a0aa; width: 839px; height: 105px; text-align: center; border-bottom: #f68428 dotted 3px; font-weight: normal; line-height: 43px; text-transform: uppercase;">Livre Mercado</h2>

                    <p style="margin: 41px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #363636; line-height: 28px;">Acreditamos que no livre mercado - onde as trocas são feitas de maneira espontânea - os serviços são melhores do que aqueles ofertados pelo Estado, dados os mesmos custos.</p>
                
                    <a onclick="fechaModal(this);" style="position: absolute; bottom: 23px; right: 24px;" href="javascript: return false;"><img border="0" alt="X" src="img/home/bt_modal_fechar.png"></a>

                </div>

                <div style="clear: both;"></div>
            </section>

            <section style="width: 950px; margin: 0 auto 61px auto;">
                <h1 style="width: 950px; height: 99px; background: url(img/home/tit_desafiosdonovo.png) top center no-repeat; margin: 0 auto 16px auto; text-indent: -9999px;">Desafios do NOVO</h1>
                
                <div style="float: left;">
                    <div style="width: 303px; height: 225px; float: left; margin: 0 10.25px 10.25px 0; background: url(img/home/bg_desafiosdonovo.png) top center no-repeat;">
                        <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 30px; color: #17a0aa; line-height: 34px; width: 258px; border-bottom: #f68428 dotted 3px; font-weight: normal; text-transform: uppercase; text-align: center; margin: 30px auto 0 auto;">Inovar</h2>

                        <p style="font-family: 'UniversLTStd-Cn', Arial; font-size: 14px; color: #464646; display: block; width: 258px; margin: 15px auto 0 auto; text-transform: uppercase; line-height: 16px;">Criar um espaço diferenciado no cenário político nacional através do NOVO.</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 0 10.25px 10.25px 10.25px; background: url(img/home/bg_desafiosdonovo.png) top center no-repeat;">
                        <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 30px; color: #17a0aa; line-height: 34px; width: 258px; border-bottom: #f68428 dotted 3px; font-weight: normal; text-transform: uppercase; text-align: center; margin: 30px auto 0 auto;">Conscientizar</h2>

                        <p style="font-family: 'UniversLTStd-Cn', Arial; font-size: 14px; color: #464646; display: block; width: 258px; margin: 15px auto 0 auto; text-transform: uppercase; line-height: 16px;">Conscientizar o indivíduo da sua responsabilidade como cidadão e torná-lo sócio do projeto.</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 0 0 10.25px 10.25px; background: url(img/home/bg_desafiosdonovo.png) top center no-repeat;">
                        <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 30px; color: #17a0aa; line-height: 34px; width: 258px; border-bottom: #f68428 dotted 3px; font-weight: normal; text-transform: uppercase; text-align: center; margin: 30px auto 0 auto;">Atrair e Engajar</h2>

                        <p style="font-family: 'UniversLTStd-Cn', Arial; font-size: 14px; color: #464646; display: block; width: 258px; margin: 15px auto 0 auto; text-transform: uppercase; line-height: 16px;">Motivar o cidadão a atuar na política com honestidade e visão de longo prazo.</p>
                    </div>

                    <div style="width: 303px; height: 225px; float: left; margin: 10.25px 10.25px 10.25px 0; background: url(img/home/bg_desafiosdonovo.png) top center no-repeat;">
                        <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 30px; color: #17a0aa; line-height: 34px; width: 258px; border-bottom: #f68428 dotted 3px; font-weight: normal; text-transform: uppercase; text-align: center; margin: 30px auto 0 auto;">Defender</h2>

                        <p style="font-family: 'UniversLTStd-Cn', Arial; font-size: 14px; color: #464646; display: block; width: 258px; margin: 15px auto 0 auto; text-transform: uppercase; line-height: 16px;">Preservar as liberdades individuais e a propriedade privada em oposição a conceitos coletivistas e ao Estado Paternalista.</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 10.25px 10.25px 10.25px 10.25px; background: url(img/home/bg_desafiosdonovo.png) top center no-repeat;">
                        <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 30px; color: #17a0aa; line-height: 34px; width: 258px; border-bottom: #f68428 dotted 3px; font-weight: normal; text-transform: uppercase; text-align: center; margin: 30px auto 0 auto;">Educar</h2>

                        <p style="font-family: 'UniversLTStd-Cn', Arial; font-size: 14px; color: #464646; display: block; width: 258px; margin: 15px auto 0 auto; text-transform: uppercase; line-height: 16px;">Garantir o acesso a educação básica de qualidade criando um ambiente baseado no mérito.</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 10.25px 0 10.25px 10.25px; background: url(img/home/bg_desafiosdonovo.png) top center no-repeat;">
                        <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 30px; color: #17a0aa; line-height: 34px; width: 258px; border-bottom: #f68428 dotted 3px; font-weight: normal; text-transform: uppercase; text-align: center; margin: 30px auto 0 auto;">Reduzir</h2>

                        <p style="font-family: 'UniversLTStd-Cn', Arial; font-size: 14px; color: #464646; display: block; width: 258px; margin: 15px auto 0 auto; text-transform: uppercase; line-height: 16px;">Rever o papel do Estado, reduzindo o escopo da sua atuação e a carga tributária.</p>
                    </div>

                    <div style="width: 303px; height: 225px; float: left; margin: 10.25px 10.25px 0 0; background: url(img/home/bg_desafiosdonovo.png) top center no-repeat;">
                        <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 30px; color: #17a0aa; line-height: 34px; width: 258px; border-bottom: #f68428 dotted 3px; font-weight: normal; text-transform: uppercase; text-align: center; margin: 30px auto 0 auto;">Desburocratizar</h2>

                        <p style="font-family: 'UniversLTStd-Cn', Arial; font-size: 14px; color: #464646; display: block; width: 258px; margin: 15px auto 0 auto; text-transform: uppercase; line-height: 16px;">Simplificar a complexa legislação e regulamentação, desonerando o pagador de impostos, estimulando a economia e combatendo a corrupção.</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 10.25px 10.25px 0 10.25px; background: url(img/home/bg_desafiosdonovo.png) top center no-repeat;">
                        <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 30px; color: #17a0aa; line-height: 34px; width: 258px; border-bottom: #f68428 dotted 3px; font-weight: normal; text-transform: uppercase; text-align: center; margin: 30px auto 0 auto;">Administrar</h2>

                        <p style="font-family: 'UniversLTStd-Cn', Arial; font-size: 14px; color: #464646; display: block; width: 258px; margin: 15px auto 0 auto; text-transform: uppercase; line-height: 16px;">Implantar uma gestão pública eficiente, promovendo a boa governança e a transparência dos gastos, ciente de que os recursos públicos são escassos. </p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 10.25px 0 0 10.25px; background: url(img/home/bg_desafiosdonovo.png) top center no-repeat;">
                        <h2 style="font-family: 'UniversLTStd-BoldCn', Arial; font-size: 30px; color: #17a0aa; line-height: 34px; width: 258px; border-bottom: #f68428 dotted 3px; font-weight: normal; text-transform: uppercase; text-align: center; margin: 30px auto 0 auto;">Promover</h2>

                        <p style="font-family: 'UniversLTStd-Cn', Arial; font-size: 14px; color: #464646; display: block; width: 258px; margin: 15px auto 0 auto; text-transform: uppercase; line-height: 16px;">Promover a livre iniciativa com o estímulo a um ambiente empreendedor, estabelecendo regras transparentes, adequando a legislação trabalhista, simplificando a estrutura tributária e priorizando o interesse do consumidor.</p>
                    </div>
                </div>
                <div style="clear: both;"></div>
            </section>

            <section style="width: 950px; margin: 0 auto 35px auto;">
                <h1 style="width: 950px; height: 99px; background: url(img/home/tit_nossosdiferenciais.png) top center no-repeat; margin: 0 auto 16px auto; text-indent: -9999px;">Nossos diferenciais</h1>
                
                <div style="float: left;">
                    <div style="width: 303px; height: 225px; float: left; margin: 0 10.25px 10.25px 0;">
                        <h2 style="width: 303; height: 66px; background: url(img/home/tit_nossosdiferenciais_fichalimpa.png) top center no-repeat;"></h2>

                        <p style="display: block; width: 303px; margin: 12px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #ffffff; line-height: 18px;"><strong style="text-transform: uppercase;">Ficha Limpa</strong>: Filiados e candidatos devem preencher os pré requisitos da lei Ficha Limpa;</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 0 10.25px 10.25px 10.25px;">
                        <h2 style="width: 303; height: 66px; background: url(img/home/tit_nossosdiferenciais_limites.png) top center no-repeat;"></h2>

                        <p style="display: block; width: 303px; margin: 12px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #ffffff; line-height: 18px;"><strong style="text-transform: uppercase;">Limitação ao “carreirismo político”</strong>: é vetado ao filiado eleito para cargo no Poder Legislativo que se candidate a mais de uma reeleição consecutiva para o mesmo cargo;</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 0 0 10.25px 10.25px;">
                        <h2 style="width: 303; height: 66px; background: url(img/home/tit_nossosdiferenciais_gestao.png) top center no-repeat;"></h2>

                        <p style="display: block; width: 303px; margin: 12px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #ffffff; line-height: 18px;"><strong style="text-transform: uppercase;">Gestão independente</strong>: a gestão partidária não pode ser feita por candidato ou por ocupante de cargo eletivo;</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 10.25px 10.25px 0 0;">
                        <h2 style="width: 303; height: 66px; background: url(img/home/tit_nossosdiferenciais_compromisso.png) top center no-repeat;"></h2>

                        <p style="display: block; width: 303px; margin: 12px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #ffffff; line-height: 18px;"><strong style="text-transform: uppercase;">Compromisso de cumprimento do mandato parlamentar</strong>: a renúncia a mandato eletivo para concorrer a cargo diverso ou ocupar cargo no Executivo, sem o aval do Diretório, é considerado ato de indisciplina partidária;</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 10.25px 10.25px 0 10.25px;">
                        <h2 style="width: 303; height: 66px; background: url(img/home/tit_nossosdiferenciais_vinculacao.png) top center no-repeat;"></h2>

                        <p style="display: block; width: 303px; margin: 12px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #ffffff; line-height: 18px;"><strong style="text-transform: uppercase;">Vinculação do candidato às suas propostas</strong>: definição prévia do Compromisso de Gestão e do Compromisso de Atuação Legislativa prevendo metas a serem cumpridas;</p>
                    </div>
                    <div style="width: 303px; height: 225px; float: left; margin: 10.25px 0 0 10.25px;">
                        <h2 style="width: 303; height: 66px; background: url(img/home/tit_nossosdiferenciais_cobrancas.png) top center no-repeat;"></h2>

                        <p style="display: block; width: 303px; margin: 12px 0 0 0; text-align: center; font-family: Arial; font-size: 18px; color: #ffffff; line-height: 18px;"><strong style="text-transform: uppercase;">Não há cobrança de percentual do salário do mandatário</strong>: a contribuição partidária mínima é igual para filiados e candidatos eleitos.</p>
                    </div>
                </div>
                <div style="clear: both;"></div>
            </section>

            <div id="cadastro" style="width: 100%; background: url(img/bg_cadastrese.png) bottom center repeat-x; background-color: #f4f0e7;">
                <section style="width: 872px; margin: 0 auto; padding: 63px 39px;">

                    
					<?php if($_GET['enviado'] == "2") : ?>
                    
                    <h2 style="font-face: Arial; font-size: 29px; color: #f68428; margin-bottom: 27px;">Obrigado!</h2>
                    <h3 style="font-face: Arial; font-size: 18px; color: #646564; font-weight: normal; margin-bottom: 40px;"><strong>Obrigado pela Confirmação.</strong><br />Se você ainda não fez o seu cadastro no NOVO, aproveite e faça abaixo.
                    <div style="height: 27px;"><!-- --></div>
                    <br /><br />
                    </h3>
                 
                    <?php endif; ?>

					
					<?php if ($_GET['enviado'] == NULL OR $_GET['enviado']  == "2") : ?>
                    <h2 style="font-face: Arial; font-size: 29px; color: #f68428; margin-bottom: 27px;">Cadastre-se</h2>
                    <h3 style="font-face: Arial; font-size: 18px; color: #646564; font-weight: normal; margin-bottom: 40px;"><strong>Receba informativos do NOVO.</strong><br />
                    <div style="height: 27px;"><!-- --></div>
                    Complete o formulário abaixo para receber notícias sobre o NOVO.<br />
                    </h3>

                    <form name="cadastro" method="post" action="../p/envia_cadastro_home.php" enctype="multipart/form-data" onsubmit="envia_cadastro_home(this); return false;">
                        <label style="margin-left: 5px;">Nome:</label><input type="text" id="nome" name="nome" style="width: 278px; padding: 0 5px;" /><br />
                        <div style="height: 12px;"><!-- --></div>
                        <label style="margin-left: 5px;">E-mail:</label><input type="text" id="email" name="email" style="width: 278px; padding: 0 5px;" /><br />
                        <div style="height: 12px;"><!-- --></div>
                        <label style="margin-left: 5px;">CEP:</label><input type="text" id="cep" name="cep" style="width: 134px; padding: 0 5px;" onKeyPress="MascaraCep(cadastro.cep);"
 maength="10"/><label style="margin-left: 4px;">Profissão:</label><input type="text" id="profissao" name="profissao" style="width: 278px; padding: 0 5px;" /> <div style="height: 12px;"><!-- --></div>
                        <label style="margin-left: 5px;">Endereço:</label><input type="text" id="endereco" name="endereco" style="width: 350px; padding: 0 5px;" /><label style="margin-left: 16px;">Número:</label><input type="text" id="numero" name="numero" style="width: 50px; padding: 0 5px;"/><br />
                        <div style="height: 12px;"><!-- --></div>
                        <label style="margin-left: 5px;">Cidade:</label><input type="text" id="cidade" name="cidade" style="width: 134px; padding: 0 5px;" /><label style="margin-left: 16px; width: 65px;">Estado:</label><input type="text" id="estado" name="estado" style="width: 35px; padding: 0 5px;" maxlength="2" /><label style="margin-left: 8px;">Telefone:</label>
                        <input type="text" id="telefone" name="telefone" style="width: 144px; padding: 0 5px;" onKeyPress="MascaraTelefone(cadastro.telefone);"/><br />
                        <div style="height: 12px;"><!-- --></div>
                        <input type="checkbox" id="sms" name="sms" value="1" checked style=width: 15px; height: 100px; padding: 0px 0px;" />
                        <span style="vertical-align:8px; font-size: x-small;">
                        Autorizo o envio de SMS ou WhatsApp para meu telefone.
                        </span>
                        <br />
						<div style="height: 27px;"><!-- --></div>
                      <input type="image" name="submit" src="img/bt_formulario_enviar.png" style="width: 98px; height: 32px; border: none; outline: none;" />
                        <input type="hidden" id="action" name="action" value="submitform" />
                        <input type="hidden" name="charset_check" value="ä™®">
                    </form>
					
					<?php endif; ?>

					<?php if($_GET['enviado'] == "1") : ?>
             
                    <h2 style="font-face: Arial; font-size: 29px; color: #f68428; margin-bottom: 27px;">Obrigado!</h2>
                    <h3 style="font-face: Arial; font-size: 18px; color: #646564; font-weight: normal; margin-bottom: 40px;"><strong>Agradecemos seu interesse pelo Partido NOVO.</strong><br />
                    <div style="height: 27px;"><!-- --></div>
                    <br /><br />
                    </h3>
                    <?php endif; ?>

                </section>
            </div>
            
            <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">
            </script>
            <script>
			$("#cep").blur(function(){
			var cep = this.value.replace(/[^0-9]/, "");
			if(cep.length!=8){
			return false;
			}
			var url = "http://viacep.com.br/ws/"+cep+"/json/";
			$.getJSON(url, function(dadosRetorno){
			try{
			// Insere os dados em cada campo
			$("#endereco").val(dadosRetorno.logradouro);
			$("#cidade").val(dadosRetorno.localidade);
			$("#estado").val(dadosRetorno.uf);
			}catch(ex){}
			});
			});
			</script>


            <footer style="width: 100%; height: 71px; background: url(img/bg_rodape.jpg);">
                <div style="width: 100%; height: 5px; background-color: #ffffff;"><!-- --></div>
                <div id="footer_in" style="width: 927px; margin: 0 auto; padding: 21px 0 0 23px;">
                    <img src="img/logo_rodape.png" alt="Partido NOVO | Gestão e Cidadania" />
    
                    <a href="http://www.zaw.com.br/" target="_blank"><img src="img/zaw.png" alt="ZAW" style="float: right; margin-left: 40px; position: relative; bottom: -6px;" border="0" /></a>

                    <nav style="float: right;">
                        <ul>
                            <li><a href="javascript: return false;" onclick="$('body,html').animate({scrollTop: 0}, 800); return false;">De volta ao topo</a></li>
                        </ul>
                    </nav>
                </div>
            </footer>
        </div>



        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.0.min.js"><\/script>')</script>

        <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>

        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
        <script src="js/home.js"></script>

        <?php if($detect->isMobile()) : ?>
        <script src="js/nossosideais_mobile.js"></script>
        <script src="js/menu_mobile.js"></script>
        <?php else : ?>
        <script src="js/nossosideais.js"></script>
        <script src="js/menu.js"></script>
        <?php endif; ?>

        <script>

        function fechaModal(el) {
            
            $("#modal_principal").show();
            $(el).parent().hide();

        }

        (function() {

            if(window.location.hash == '#ideais') {

                $("#balao_nossosideais").css("background-image", "url(img/menu/nossosideais_selecionado.png)");

            }
            
            last_random_number = -1;

            setInterval(function() {
                
                do {

                    random_number = Math.floor(Math.random() * 15);

                } while(random_number == last_random_number) 

                $("#tag").effect("bounce", {times: 1, direction: "down", distance: 10}, 1000);

                $("#tag img").animate({opacity: 0}, 500, function() {
                        
                    $("#tag img").attr("src", "img/home/tag_" + membros[random_number][0] + ".png");

                }).show('fade').animate({opacity: 1}, 500);

                last_random_number = random_number;

            }, 5000)

        }());
        </script>

        <?php if(isset($f) && !empty($f)) : ?>
        <script>
        (function() {

            location.href= '#<?php echo $f; ?>';

        }());
        </script>
        <?php endif; ?>

        <script type="text/javascript">
          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-21651021-1']);
          _gaq.push(['_trackPageview']);

          (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();
        </script>
    </body>
</html>
